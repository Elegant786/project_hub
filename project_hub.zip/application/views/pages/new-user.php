	
	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url()?>dashboard">Home</a>
							</li>

							<li>
								<a href="#">User Management</a>
							</li>
							<li class="active">New User</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">

							
							<!--<div class="row">
								<div class="col-md-2">
									<button onclick="HideDiv()"  class="btn btn-success btn-xs" id="btn"> Add Existing user </button>
								</div>
							</div>-->
							<div style="height:20px;"></div>
						<div class="row">
							<div class="col-xs-12">

								<?php
								if(validation_errors()){
									echo "<div class='alert alert-danger'>".validation_errors()."</div>";
								}
								if(isset($_GET['action']) && $_GET['action']=='failed' ){
									echo "<div class='alert alert-warning'>User Not Added</div>";
								}

								if(isset($_GET['action']) && $_GET['action']=='success' ){
									echo "<div class='alert alert-success'>User Created</div>";
								}

								if(isset($_GET['action']) && $_GET['action']=='updated' ){
									echo "<div class='alert alert-success'>Users Data Updated Successfully :)</div>";
								}

								if(isset($_GET['action']) && $_GET['action']=='error' ){
									echo "<div class='alert alert-danger'>Users Data Not Updated :)</div>";
								}
								if(isset($upload_error)){
									echo "<div class='alert alert-danger'>".$upload_error."</div>";

								}
							?>
								<!-- PAGE CONTENT BEGINS -->
								<div class="col-md-5" style="display: none;" id="myDIV">
									<div class="panel panel-default">
											<div class="panel panel-heading"><div class="panel-title"> Existing User </div></div>
												<div class="panel-body">
													<fieldset>
														<?php echo form_open("edit-add")?>
												<div class="form-group">
													<label>Email</label>
													<input type="email" oninput="FindUser(this.value)" name="email" class="form-control" required="required" placeholder="Email Address">

												</div>

												<div id="showUser">

												</div>
												

									            <div class="form-group">
														<label>user Level</label>
														<select onchange="GetPrecedant2(this.value)" name="level" class="form-control">
																<option>Select Level</option>
																<option value="3">User</option>
																<option value="2">Admin</option>
														</select>
												</div>
												<div class="form-group" id="getpres2">

												</div>
									            <div class="clearfix">
														<button type="submit" class="width-65 pull-right btn btn-sm btn-success">
															<span class="bigger-110">Register</span>

															<i class="ace-icon fa fa-arrow-right icon-on-right"></i>
														</button>
													</div>
														<?php echo form_close()?>
												</fieldset></div>

									</div>

								</div>


									<div class="col-md-5" id="hideme">
										<div class="panel panel-default">
											<div class="panel panel-heading"><div class="panel-title"> Create user </div></div>
												<div class="panel-body">
														<?php echo form_open_multipart("add-user")?>
															<div class="form-group">
												<fieldset>

													<label class="block clearfix">
														<label>Name</label>
														<span class="block input-icon input-icon-right">
															<input type="text" class="form-control" placeholder="Name" name="name" required="required" />
															<i class="ace-icon fa fa-user"></i>
														</span>
													</label>

													<label class="block clearfix">
														<label>E-mail</label>
														<span class="block input-icon input-icon-right">
															<input type="email" class="form-control" placeholder="Email" required="required" name="email" />
															<i class="ace-icon fa fa-envelope"></i>
														</span>
													</label>

													<label class="block clearfix">
														<label>Gender</label><br>
														<label class="inline">
															<input type="radio" class="ace" name="gender" value="1" />
															<span class="lbl"> Male</span>
														</label>

														<label class="inline">
															<input type="radio" class="ace" name="gender" value="2" />
															<span class="lbl"> Female</span>
														</label>
													</label>


													<label class="block clearfix">
														<label>photo</label>
														<span class="block input-icon input-icon-right">
															<input type="file" name="image" >
															<i class="ace-icon fa fa-home"></i>
														</span>
													</label>
													<!--
													<div class="form-group">
									                    <label class="control-label">Category</label>
									                    <select name="cat_id" class="form-control">
									                    		<option> SELECT CATEGORY</option>
									                    	<?php 
																$query = $this->db->get('category');
																$result = $query->result();
																foreach($result AS $row):
																	
															?>
															<option value="<?php echo $row->cat_id?>"><?php echo $row->cat_name?></option>
														<?php endforeach;?>
									                    </select>
									                </div> -->
														
													
													<div class="space-24"></div>

													<div class="clearfix">
														<button type="submit" class="width-65 pull-right btn btn-sm btn-success">
															<span class="bigger-110">Register</span>

															<i class="ace-icon fa fa-arrow-right icon-on-right"></i>
														</button>
													</div>

												</fieldset>
															</div>

														<?php echo form_close()?>
												</div>
										</div>
									</div>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>
<script>
	function HideDiv() {
	    var x = document.getElementById("myDIV");
	    var y = document.getElementById("hideme");
	    var z = document.getElementById("btn");
	    if (x.style.display === "none") {
	        x.style.display = "block";
	        y.style.display = 'none';
	        z.innerHTML= "Add new user";
	    } else {
	        x.style.display = "none";
	        y.style.display = 'block';
	        z.innerHTML= "Add Exiting user";

	    }
	}


	function FindUser(str) {
		
	  var xhttp; 
	  if (str == "") {
	    document.getElementById("showUser").innerHTML = "";
	    return;
	  }
	  xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
	    if (this.readyState == 4 && this.status == 200) {
	    document.getElementById("showUser").innerHTML = this.responseText;
	    }
	  };
	  xhttp.open("GET", "<?php echo base_url()?>AdminController/AjaxUserData/?email="+str, true);
	  xhttp.send();
	}

	function GetPrecedant(str){
		var xhttp; 
		  if (str == "") {
		    document.getElementById("getpres").innerHTML = "";
		    return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
		    if (this.readyState == 4 && this.status == 200) {
		    document.getElementById("getpres").innerHTML = this.responseText;
		    }
		  };
		  xhttp.open("GET", "<?php echo base_url()?>AdminController/MakePrecedant/"+str, true);
		  xhttp.send();
	}

	function GetPrecedant2(str){
		var xhttp; 
		  if (str == "") {
		    document.getElementById("getpres2").innerHTML = "";
		    return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
		    if (this.readyState == 4 && this.status == 200) {
		    document.getElementById("getpres2").innerHTML = this.responseText;
		    }
		  };
		  xhttp.open("GET", "<?php echo base_url()?>AdminController/MakePrecedant/"+str, true);
		  xhttp.send();
	}

</script>