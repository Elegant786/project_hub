<?php
	if(isset($data)){
		foreach($data AS $row):	
		@$sl++;	
?>

<tr>
	<td><?php echo $sl?></td>
	<td><?php echo $row->form_id;?></td>
	<td><?php echo $row->sub_date;?></td>
	<td><?php date('d-m-Y',strtotime("+1 days"));?></td>
	<td>SM</td>
	<td>SM</td>
</tr>
<?php endforeach; }?>