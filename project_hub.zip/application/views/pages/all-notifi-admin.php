	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Other Pages</a>
							</li>
							<li class="active">Blank Page</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-6">
								<!-- PAGE CONTENT BEGINS -->
									<table class="table table-bordered">
										<thead>
											<tr>
												<td width="10">S/N</td>
												<td>Subject</td>
												<td width="40">Action</td>
											</tr>
										</thead>
										<tbody>
										<?php
											if(isset($data)):
												foreach($data AS $row):
													@$sl++;
										?>
											<tr>
												<td><?php echo $sl;?></td>
												<td><?= $row->title;?></td>
												<td><a class="btn btn-success" href="<?php echo base_url()?>dashboard/notification/view/<?php echo $row->not_id;?>"><i class="fa fa-eye"></i> view</a></td>
											</tr>
										<?php endforeach; endif;?>

										</tbody>
									</table>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>