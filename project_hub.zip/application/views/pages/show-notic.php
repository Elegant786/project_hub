	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Notification </a>
							</li>
							<li class="active">View</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-5">
								<!-- PAGE CONTENT BEGINS -->
									<div class="panel panel-default">
										<div class="panel-heading"><div class="panel-title"> Notification </div></div>	
										<div class="panel-body">
											<?php
												$id = $this->uri->segment(4);
												$query = $this->db->query("SELECT * FROM `notification` WHERE `notif_id` = $id ");
												$result = $query->result();
												foreach($result AS $row):
											?>
											<h3><?php echo $row->title?></h3>
											<h6><i class='fa fa-calendar'></i> &nbsp<?php echo $row->date?></h6>
											<p>
												<?php echo $row->details;?>
											</p>

										<?php endforeach;?>
										</div>
									</div>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
							<div class="col-md-5">
								<div class="col-md-12">
									<?php
										if(isset($_POST['submit'])){
											$us = $_POST['user'];
											$notice = $_POST['not_id'];
											$date = date('d-m-Y');

											for($i=0;$i<count($_POST['user']); $i++){
													$user = $us[$i];
													$attr = array(
															'user_id'  => $user,
															'notice_id'=> $notice,
															'date_ad'  => $date,
															'status'   => 1
													);
												$this->db->insert('admin_notice',$attr);

											}
										}
									?>
								</div>
							<?php
								if($this->session->userdata('level')==2 && $this->session->userdata('prse')==1){
							?>

								<div class="panel panel-default">
									<div class="panel-heading"><div class="panel-title"> Notify Them </div></div>
									<div class="panel-body">
										<?php echo form_open();
											echo form_hidden('not_id', $this->uri->segment(4));
										?>
											<table class="table table-bordered">
												<?php
													$cat = $this->session->userdata('cat');
													

														$query = $this->db->query("SELECT * FROM `admin` WHERE `level` = 2 AND `cat_id` = '$cat' AND `prse` = 0");
														$result = $query->result();
														if($query->num_rows()>0){	

														foreach($result AS $row):									
												?>
												<tr>
													<td> <input name="user[]" type='checkbox' value="<?php echo $row->user_id?>">  <?php echo $row->name;?></td>
												</tr>
												<?php endforeach; } else{ echo "<tr><td>ss</td></tr>"; }?>
											</table>

											<div class="col-md-12">
													<button name="submit" class="btn btn-success" type="submit">Notice User</button>
											</div>
										<?php echo form_close()?>
									</div>
								</div>
								<?php }?>


							</div>
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>