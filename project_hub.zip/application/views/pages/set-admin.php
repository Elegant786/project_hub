	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Sub Category</a>
							</li>
							<li class="active">Set Sub Category's Admin</li>
						</ul><!-- /.breadcrumb -->

						
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<?php
									if(isset($_POST['submit'])){
										$cat = $_POST['cat'];
										$sub = $_POST['subcat'];
										$us = $_POST['user'];
										for($i = 0;  $i<count($_POST['user']); $i++){
											$user = $us[$i];
											$attr = array(
												'cat_id' => $cat,
												'sub_id' => $sub
											);
											$query = $this->db->query("SELECT * FROM `admin` WHERE `user_id` = '$user' AND `cat_id` = '$cat' AND `sub_id` = '$sub' ");
											if($query->num_rows()==0){
												$this->db->where('user_id',$user);
												$this->db->update('admin',$attr);
											}
										}

									}
								?>
							</div>

							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->										
									<div class="col-md-4">
										<div class="panel panel-default">
											<div class="panel-heading"><div class="panel-title"> Set Admin </div></div>
											<div class="panel-body">
												<?php echo form_open()?>

													<input type="hidden" name="cat" value="<?php echo $this->uri->segment(4)?>">
													<input type="hidden" name="subcat" value="<?php echo $this->uri->segment(5)?>">
													<table class="table table-bordered table-hover">
														
														<?php
															$cat = $this->uri->segment(4);
															$sub = $this->uri->segment(5);
															
															$query = $this->db->query("SELECT * FROM `admin` WHERE `level` = 2 AND `prse` = 0");
															$result =$query->result();

															foreach($result AS $row):
														?>
															<tr>
																<td><label for="user"><input type="checkbox" name="user[]" value="<?php echo $row->user_id;?>"> &nbsp <?php echo $row->name?></label></td>
															</tr>

														<?php endforeach;?>
													</table>
													<div class="form-group">
														<input type="submit" name="submit" class="btn btn-success">
													</div>

												<?php echo form_close()?>
											</div>
										</div>
									</div>	

									<div class="col-md-5 pull-right">
										<div class="panel panel-default">
											<div class="panel-heading">
												<div class="panel-title">
													ALL Admins of Category
												</div>
											</div>
											<div class="panel-body">
												<table class="table table-bordered">
													<?php 
														$cat = $this->uri->segment(4);
														$sub = $this->uri->segment(5);

														$query = $this->db->query(" SELECT * FROM `admin` WHERE `cat_id` = '$cat'  AND `level` = 2 ");

														$result = $query->result();
														foreach($result AS $row):

														if($row->prse == 1){
													?>
													<tr style="background-color:#3b914e; color: #FFF; ">
														<td><?php echo $row->name?> (President)</td>										
													</tr>
													<?php }else{?>
													<tr>
														<td><?php echo $row->name?></td>										
													</tr>

												<?php } endforeach;?>
												</table>
											</div>
										</div>
									</div>							
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>