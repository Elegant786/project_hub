	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">User Management</a>
							</li>
							<li class="active">All users</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
										<div class="col-sm-12 widget-container-col ui-sortable" id="widget-container-col-10">
											<div class="widget-box ui-sortable-handle" id="widget-box-10">
												<div class="widget-header widget-header-small">
													<div class="widget-toolbar no-border pull-left">
														<ul class="nav nav-tabs" id="myTab">
															

															<li class="">
																<a data-toggle="tab" href="#profile" aria-expanded="false">Admins</a>
															</li>

															<li class="active">
																<a data-toggle="tab" href="#info" aria-expanded="false">Co-worker</a>
															</li>

														</ul>
													</div>
												</div>

												<div class="widget-body">
													<div class="widget-main padding-6">
														<div class="tab-content">
														
															<div id="home" class="tab-pane">
																<table class="table table-bordered table-hover table-responsive">
																	<tr>
																		<td>#</td>
																		<td>User ID</td>
																		<td>Name(Organization)</td>
																		<td>Email</td>
																		<td>Category</td>
																		<td>Level</td>
																		<td>Action</td>
																	</tr>

																	<?php
																		$query = $this->db->select("*")
																						  ->from('admin')
																						  ->where('level',1)
																						  ->get();
																		$result = $query->result();
																		foreach($result AS $row){
																			@$sl1++;
																	?>
																	<tr>
																		<td><?php echo $sl1?></td>
																		<td><?php echo $row->uid?></td>
																		<td><?php echo $row->name?>(<?php echo $row->organization?>)</td>
																		<td><?php echo $row->email;?></td>
																		<td><?php
																			$query2 = $this->db->select("*")
																							   ->from("Category")
																							   ->where('cat_id',$row->cat_id)
																							   ->get();
																			if($query2->num_rows()>0){
																			echo "<a href='#' class='btn btn-success btn-xs'>".$query2->row(0)->cat_name."</a>";
																			}else{
																				echo "--";
																			}
																		?></td>
																		
																		<td><?php
																			if($row->level==1){
																				echo "Super Admin";
																			}elseif($row->level==2){
																				echo "Admin";
																			}else{
																				echo "User";
																			}
																		?></td>
																		
																		
																	</tr>
																	<?php }?>
																</table>


															</div>

															<div id="profile" class="tab-pane">
																<table class="table table-bordered table-hover table-responsive">
																	<thead>
																		<tr>
																			<td>#</td>
																			<td>User ID</td>
																			<td>Name(Organization)</td>
																			<td>Email</td>
																			<td>Category</td>
																			<td>Sub Category</td>
																			<td>Level</td>
																			<td>Action</td>
																			
																		</tr>
																	</thead>

																	<?php
																		$query = $this->db->select("*")
																						  ->from('admin')
																						  ->where('level',2)
																						  ->get();
																		$result = $query->result();
																		foreach($result AS $row){
																			@$sl2++;
																	?>
																	<tr>
																		<td><?php echo $sl2?></td>
																		<td><?php echo $row->uid?></td>
																		<td><?php echo $row->name?>(<?php echo $row->organization?>)</td>
																		<td><?php echo $row->email?></td>
																		<td><?php
																			$query2 = $this->db->select("*")
																							   ->from("Category")
																							   ->where('cat_id',$row->cat_id)
																							   ->get();
																			if($query2->num_rows()>0){
																			echo "<a href='#' class='btn btn-success btn-xs'>".$query2->row(0)->cat_name."</a>";
																			}

																		?></td>
																		<td><?php 

																			$sq = $this->db->query("SELECT * FROM `sub_cat` WHERE `sub_id` = '$row->sub_id' ");
																			if($sq->num_rows() >0){
																				echo $sq->row(0)->sub_name;
																			}

																		?></td>
																		<td><?php
																			if($row->level==1){
																				echo "Super Admin";
																			}elseif($row->level==2){
																				echo "Admin";
																			}else{
																				echo "User";
																			}
																		?></td>
																		
																		
																	</tr>
																	<?php }?>

																</table>

															</div>

												<div id="info" class="tab-panel active">
															<table class="table table-bordered table-hover table-responsive">
																	<thead>
																		<tr>
																			<td>#</td>
																			<td>Co ID</td>
																			<td>Name</td>
																			<td>Email</td>
																			
																			<td>Admin Type</td>
																			<td>Level</td>
																			<td>Action</td>
																			
																		</tr>
																	</thead>
																	<?php
																		$query = $this->db->select("*")
																						  ->from('admin')
																						  ->where('level',2)
																						  ->where('cat_id',$this->session->userdata('cat'))
																						  ->get();
																		$result = $query->result();
																		foreach($result AS $row){
																			@$sl3++;
																	?>
																	<tr>
																		<td><?php echo $sl3?></td>
																		<td><?php echo $row->uid?></td>
																		<td><?php echo $row->name?></td>
																		<td><?php echo $row->email?></td>

																		
																		<td>
																			
																			<?php if($row->prse == 0){
																				echo "Admin";
																			}else{
																				echo "Presedant Admin";																				
																			}?>
																			
																		</td>
																		<td><?php
																			if($row->level==1){
																				echo "Super Admin";
																			}elseif($row->level==2){
																				echo "Admin";
																			}else{
																				echo "User";
																			}
																		?></td>
																		<td>

																				<div class="btn-group dropup">
																					<button class="btn btn-xs btn-danger">Action</button>

																					<button data-toggle="dropdown" class="btn btn-xs btn-danger dropdown-toggle">
																						<span class="ace-icon fa fa-caret-down icon-only"></span>
																					</button>

																					<ul class="dropdown-menu dropdown-danger">
																						<li>
																							<a href="<?php echo base_url()?>dashboard/edit-profile/<?php echo $row->user_id?>">Edit Profile</a>
																						</li>

																						

																						<li>
																							<a href="#">Something else here</a>
																						</li>

																						<li class="divider"></li>

																						<li>
																							<a href="#">Separated link</a>
																						</li>
																					</ul>
																				</div>

																		</td>
																		
																	</tr>
																	<?php }?>
																</table>
															</div>

														
															


														</div>
													</div>
												</div>
											</div>
										</div>


								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>