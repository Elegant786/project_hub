	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Other Pages</a>
							</li>
							<li class="active">Blank Page</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						
						
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<div class="page-content">
						
						
						<div class="row" style="margin-top: 20px;">
								<div class="col-md-12">
										<table class="table table-bordered table-responsive table-hover">
												<thead>
													<tr>
														<th width="10">#</th>
														<th> Form ID</th>
														<th>Submitted Date</th>
														<th>Approximately. Approve</th>
														<th>Status</th>
														<th>Action</th>
													</tr>
												</thead>
												<tbody id="">
													<?php
														if(isset($form)){
															//var_dump($form);
															foreach($form AS $row){
																@$sl++;


													?>
														<tr>
															<td><?php echo $sl;?></td>
															<td><?php echo $row->form_id?></td>
															<td><?php echo $row->sub_date?></td>
															<td></td>
															<td>
																<?php
																	$sta = $row->status;
																	if($sta==1){
																		echo "<span class='label label-inverse arrowed'>Save in Drafted</span>";
																	}elseif($sta==2){
																		echo "<span class='label label-warning warning'>Submited to admin</span>";
																	}elseif($sta==3){
																		echo "<span class='label label-warning warning'>Presidant Disallowed</span>";
																	}elseif($sta==5){
																		echo "<span class='label label-warning warning'>Presidant Approve with suggastion</span>";
																	}elseif($sta==4){
																		echo "<span class='label label-danger warning'>Approve By Presidant</span>";
																	}elseif($sta==6){
																		echo "<span class='label label-success success'>Super Admin Approve with suggastion</span>";
																	}elseif($sta==7){
																		echo "<span class='label label-success success'>Approve By Super Admin</span>";
																	}
																	elseif($sta==8){
																		echo "<span class='label label-success success'>Disallowed By Super Admin</span>";
																	}
																	elseif($sta==9){
																		echo "<span class='label label-danger danger'>Allow By Admin</span>";
																	}
																	elseif($sta==10){
																		echo "<span class='label label-danger danger'>Suggest By Admin</span>";
																	}
																	elseif($sta==11){
																		echo "<span class='label label-danger danger'>Disallowed By Admin</span>";
																	}
																?>
															</td>
															<td>
																
																<div class="btn-group dropup">
																	<button class="btn btn-xs btn-danger">Action</button>

																	<button data-toggle="dropdown" class="btn btn-xs btn-danger dropdown-toggle" aria-expanded="false">
																		<span class="ace-icon fa fa-caret-down icon-only"></span>
																	</button>

																	<ul class="dropdown-menu dropdown-danger">
																		<?php
																			if($this->session->userdata('level')==1){
																		?>
																			<?php
																				if($row->status== 9 || $row->status== 10||  $row->status== 11 || $row->status== 2){
																			?>
																				<li>
																					<a href="#">View / Edit</a>
																				</li>
																				<?php }else{?>
																					<li>
																						<a href="<?php echo base_url()?>dashboard/view-materials/<?php echo $row->f_id?>">View / Edit</a>
																					</li>
																				<?php } }else{?>
<li>
																						<a href="<?php echo base_url()?>dashboard/view-materials/<?php echo $row->f_id?>">View / Edit</a>
																					</li>

																				<?php }?>

																		<li>
																			<a href="#">Another action</a>
																		</li>

																		<li>
																			<a href="#">Something else here</a>
																		</li>

																		<li class="divider"></li>

																		<li>
																			<a href="#">Separated link</a>
																		</li>
																	</ul>
																</div>

															</td>
														</tr>


													<?php } if($this->pagination->create_links()){?>
														<tr>
															<td colspan="6"><?php echo $this->pagination->create_links()?></td>
															
														</tr>

													<?php } }?>
												</tbody>
										</table>
								</div>
						</div>
					
					</div>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>