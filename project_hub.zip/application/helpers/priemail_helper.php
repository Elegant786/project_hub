<?php

function email(){
	$ci =& get_instance();
	$address = NULL;
	$query = $ci->db->get('email_settings');
		$result = $query->result();
		foreach ($result as $email) {
			$email = $email->email_address;
		}
	return $address;
}

function Pass(){
	$ci =& get_instance();
	$Password = NULL;
	$query = $ci->db->get('email_settings');
		$result = $query->result();
		foreach ($result as $email) {
			$email = $email->e_pass;
		}
	return $Password;
}

function Cc(){
	$ci =& get_instance();

	$CC = NULL;
	$query = $ci->db->get('email_settings');
		$result = $query->result();
		foreach ($result as $email) {
			$CC = $email->cc;
		}
	return $CC;
}

function Bcc(){
	$ci =& get_instance();
	$bcc = NULL;
	$query = $ci->db->get('email_settings');
		$result = $query->result();
		foreach ($result as $email) {
			$bcc = $email->email_address;
		}
	return $bcc;
}

?>