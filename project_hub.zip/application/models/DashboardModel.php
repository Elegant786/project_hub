<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardModel extends CI_Model {
	public function __construct(){
		parent::__construct();
		//Do your magic here
	}

	public function UploadFile(){
		$file_name = $this->upload->data('file_name');
		$attr = array(
			'form_code' => $_POST['fcode'],
			'file_name' => $file_name
		);

		if($this->db->insert('files',$attr)==TURE){
			return TRUE;
		}else{
			return FALSE;
		}
	}

	public function SubmitData(){
			$type = $_POST['ptype'];
			$mback = $_POST['m-back'];
			$relserv = $_POST['relserv'];
			$usermeta = $_POST['usermeta'];
			$howuse = $_POST['howuse'];
			$code = $_POST['fcode'];
			$category = $_POST['category'];
			$sub = $_POST['sub_cat'];

			$query= $this->db->query("SELECT * FROM `review_days` WHERE `cat_id` = '$sub'");
			if($query->num_rows()==1){
				$rdays = $query->row(0)->days;
			}else{
				$rdays = 10;
			}

			$req_date =  date('d-m-Y', strtotime('+'.$rdays.' day', strtotime(date('d-m-Y'))));

			$attr = array(
				'cat_id'  => $category,
				'p_rel'	  => $relserv,
				'p_type'  => $type,
				'm_back'  => $mback,
				'm_use'	  => $usermeta,
				'wh_use'  => $howuse,
				'form_id' => $code,
				'status'  => 1,
				'f_status'=> 1,
				'user_id' => $this->session->userdata('user_id'),
				'sub_date'=> date('d-m-Y'),
				'sub_cat' => $sub,
				'req_date' => $req_date,
				'days' 	   => $rdays


			);

			if($this->db->insert('forms',$attr)==TRUE){
				//$this->SendMailUserTOAdmin()
				return TRUE;
			}else{
				return FALSE;
			}

	}

	public function UpdateForm(){


			$type = $_POST['ptype'];
			$mback = $_POST['m-back'];
			$relserv = $_POST['relserv'];
			$usermeta = $_POST['usermeta'];
			$howuse = $_POST['howuse'];
			$code = $_POST['fcode'];
			$category = $_POST['category'];
			$sub = $_POST['sub'];
			$id =$_POST['id'];
			$action = $_POST['action'];

			if($action==2){
				$ndate = date('d-m-Y');
			}else{
				$ndate = "--";
			}

			$attr = array(
				'cat_id'  => $category,
				'p_rel'	  => $relserv,
				'p_type'  => $type,
				'm_back'  => $mback,
				'm_use'	  => $usermeta,
				'wh_use'  => $howuse,
				'form_id' => $code,
				'status'  => $action,
				'sub_cat' => $sub,
				
				'user_id' => $this->session->userdata('user_id'),
				'f_date'=> $ndate
			);

			 $this->db->where('f_id',$id);
		 if($this->db->update('forms',$attr)){
		 	/*if($action==2){		 		
		 		$admins = $this->db->query("SELECT * FROM `admin` WHERE `level` = '2' AND `cat_id` = '$category' ");
		 		$result = $admins->result();
		 		foreach($result AS $row){

			 		$this->load->library('email');
					$this->email->from(email(), 'Abdur Rahaman');
					$this->email->to($row->email);
					$this->email->cc(Cc());
					$this->email->bcc(Bcc());
					$this->email->subject('New Form Submitted');
					$massege = "New Form Submitted by ".$this->session->userdata('name')." Form id=".$code;
					$this->email->message($massege);
					$this->email->send();
				}

		 	} */
		 	return TRUE;
		 }else{
		 	return FALSE;
		 }

	}

	public function SendMailUserTOAdmin(){
		$this->load->library('email');
		$this->email->from('your@example.com', 'Your Name');
		$this->email->to('someone@example.com');
		$this->email->cc('another@another-example.com');
		$this->email->bcc('them@their-example.com');
		$this->email->subject('Email Test');
		$this->email->message($massegs);
		$this->email->send();
	}
		
	//Ajax

	public function CountForms(){
		$query =$this->db->select('*')
						 ->from("forms")
						 ->where('user_id',$this->session->user_id)
						 ->get();
		return $query->num_rows();
	}

	public function GetFroms($limit,$offset){
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where('user_id',$this->session->user_id)
						  ->order_by('f_id','DESC')
						  ->limit($limit,$offset)
						  ->get();
		return $query->result();
	}

	public function CoundAdminAllowed(){

		$cat = $this->session->userdata('cat');
		$sub = $this->session->userdata('sub');
	
		$query = $this->db->query(" SELECT * FROM `forms` WHERE `sub_cat`= '$sub' AND `cat_id` = '$cat' AND `status` = 2 ");
		return $query->num_rows();
	}

	public function  GetAdminAllowed($limite,$offset){
		$cat = $this->session->userdata('cat');
		$sub = $this->session->userdata('sub');
		
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where("status",2)					
						  ->where("cat_id",$cat)
						  ->where('sub_cat',$sub )					
						  ->order_by('f_id',"DESC")
						  ->limit($limite,$offset)
						  ->get();
		return $query->result();
	}


	public function CountAdminDisallowed(){
		$cat = $this->session->userdata('cat');
		$sub = $this->session->userdata('sub');
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where("status",11)
						  ->where("cat_id",$cat)
						  ->where("sub_cat",$sub)
						  ->get();
		return $query->num_rows();
	}

	public function  GetAdminDisallowed($limite,$offset){
		$cat = $this->session->userdata('cat');
		$sub = $this->session->userdata('sub');
		
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where("status",11)
						  ->where("cat_id",$cat)
						  ->where("sub_cat",$sub)
						  ->limit($limite,$offset)						  
						  ->get();
		return $query->result();
	}

	public function CountAdminsSuggForms(){

		$cat = $this->session->userdata('cat');
		$sub = $this->session->userdata('sub');
		
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where("status",10)
						  ->where("cat_id",$cat)
						  ->where("sub_cat",$sub)
						  //->limit($limite,$offset)						  
						  ->get();
		return $query->num_rows();

	}

	public function GetAdminsSuggForms($limit,$offset){

		$cat = $this->session->userdata('cat');
		$sub = $this->session->userdata('sub');
		
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where("status",10)
						  ->where("cat_id",$cat)
						  ->where("sub_cat",$sub)
						  ->limit($limit,$offset)						  
						  ->get();
		return $query->result();

	}

	public function CountPresedantReview(){

		$cat = $this->session->userdata('cat');
		$sub = $this->session->userdata('sub');		
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where("status",9)
						  ->where("cat_id",$cat)
						  ->where("sub_cat",$sub)
						  ->get();
		return $query->num_rows();

	}

	public function GetPresedantReview($limit,$offset){

		$cat = $this->session->userdata('cat');
		$sub = $this->session->userdata('sub');

		if($this->session->userdata('level')==2 && $this->session->userdata('prse')==1){
			$query = $this->db->select("*")
						  ->from("forms")
						  ->where("status",9)
						  ->where("cat_id",$cat)						  
						  ->limit($limit,$offset)						  

						  ->get();
		return $query->result();


		}else{

			$query = $this->db->select("*")
							  ->from("forms")
							  ->where("status",9)
							  ->where("cat_id",$cat)
							  ->where("sub_cat",$sub)
							  ->limit($limit,$offset)						  

							  ->get();
			return $query->result();
		}
	}

	public function AllMetaCount(){
		$query = $this->db->select("*")
						  ->from("forms")						  
						  ->get();
		return $query->num_rows();
	}

	public function  GetAllMeta($limite,$offset){
		
		$query = $this->db->select("*")
						  ->from("forms")						  
						  ->order_by('f_id',"DESC")
						  ->limit($limite,$offset)
						  ->get();
		return $query->result();
	}


	public function AdminAllMetaCount(){
		$cat = $this->session->userdata('cat');
		$sub = $this->session->userdata('sub');
		$query = $this->db->query(" SELECT * FROM `forms` WHERE `sub_cat` = '$sub' AND `cat_id` ='$cat' AND `status` != 1 ");

		return $query->num_rows();
	}

	public function  GetAdminAllMeta($limite,$offset){
		$cat = $this->session->userdata('cat');
		$sub = $this->session->userdata('sub');
		//$query = $this->db->query("SELECT * FROM `forms` WHERE `status` != 1 LIMIT  '$offset'  '$limite'");
		   $attr =  array(1);
		  $query = $this->db->select("*")
		  				 ->from("forms")						  
						  ->order_by('f_id',"DESC")
						  ->where('cat_id',$cat)
						  ->where('sub_cat',$sub)
						  ->where_not_in('status',$attr)
						  ->limit($limite,$offset)
						  ->get();
		return $query->result();
	}

	public function UserFullyApproveCount(){
		$uid = $this->session->userdata('user_id');
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where('user_id',$uid)
						  ->where('status',7)
						  ->get();
		return $query->num_rows();
	}

	
	public function GetFullyApproveCount($limit,$offset){
		$uid = $this->session->userdata('user_id');
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where('user_id',$uid)
						  ->where('status',7)
						  ->limit($limit,$offset)
						  ->get();
		return $query->result();

	}

	public function UserDisallowedCount(){
		$uid = $this->session->userdata('user_id');
		$attr = array(3,8,11);
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where('user_id',$uid)
						  ->where_in('status',$attr)
						  ->get();
		return $query->num_rows();
	}


public function UserDisallowedGet($limit,$offset){
		$uid = $this->session->userdata('user_id');
		$attr = array(3,8,11);
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where('user_id',$uid)
						  ->where_in('status',$attr)
						  ->limit($limit,$offset)
						  ->get();
		return $query->result();
	}


	public function MyDraftedCount(){
		$uid = $this->session->userdata('user_id');
		//$attr = array(3,8,11);
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where('user_id',$uid)
						  ->where('status',1)
						  ->get();
		return $query->num_rows();
	}

	public function GetMyDrafted($limit,$offset){
		$uid = $this->session->userdata('user_id');

		//$attr = array(3,8,11);
		$query = $this->db->select("*")
						  ->from("forms")
						  ->where('user_id',$uid)
						  ->where('status',1)
						  ->limit($limit,$offset)
						  ->get();
		return $query->result();
	}

	public function CountDays($from=NULL,$to=NULL,$day=NULL){
			$from = new DateTime($from);
			$to   = new DateTime($to);
			$wF = $from->format('w');
			$wT = $to->format('w');
			if ($wF < $wT)      $isExtraDay = $day >= $wF && $day <= $wT;
			elseif ($wF == $wT) $isExtraDay = $wF == $day;
			else                $isExtraDay = $day >= $wF || $day <= $wT;

			return floor($from->diff($to)->days / 7) + $isExtraDay;

	}


	public function CountCatForms($cat=NULL){
		$query = $this->db->select("*")
				          ->from("forms")
				          ->where('cat_id',$cat)
				          ->get();
		return  $query->num_rows();
	}

	public function GetCatForms($cat=NULL,$limit,$offset){
		$query = $this->db->select("*")
				          ->from("forms")
				          ->where('cat_id',$cat)
				          ->limit($limit,$offset)
				          ->get();
		return  $query->result();
	}

	public function CountNotification(){
		$query = $this->db->get('notification');
		return $query->num_rows();
	}

	public function  AllNotification($limit,$offset){
		$query = $this->db->select("*")
						  ->from('notification')
						  ->order_by('notif_id','DESC')
						  ->limit($limit,$offset)
						  ->get();
		return $query->result();
	}

	public function AdminNotificationsCount(){
		$id = $this->session->userdata('user_id');
		$query = $this->db->select("*")
				          ->from("admin_notice")
				          ->where('user_id',$id)
				          ->get();
		return  $query->num_rows();
	}

	public function AllAdminNotifications($limit,$offset){

		$id = $this->session->userdata('user_id');
		$query = $this->db->select("*")
				          ->from("admin_notice")
				          ->join('notification', "admin_notice.notice_id = notification.notif_id")
				          ->where('user_id',$id)
				          ->limit($limit,$offset)
				          ->get();
		return  $query->result();
	}


	function timeago($date) {
	   $timestamp = strtotime($date);	
	   
	   $strTime = array("second", "minute", "hour", "day", "month", "year");
	   $length = array("60","60","24","30","12","10");

	   $currentTime = time();
	   if($currentTime >= $timestamp) {
			$diff     = time()- $timestamp;
			for($i = 0; $diff >= $length[$i] && $i < count($length)-1; $i++) {
			$diff = $diff / $length[$i];
			}

			$diff = round($diff);
			return $diff . " " . $strTime[$i] . "(s) ago ";
	   }
	}


#END OF FILE
}

/* End of file DashboardModel.php */
/* Location: ./application/models/DashboardModel.php */