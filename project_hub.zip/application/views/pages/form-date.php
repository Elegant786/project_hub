	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Other Pages</a>
							</li>
							<li class="active">Blank Page</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<div class="col-md-12">
									<?php
										if(isset($_POST['submit'])){
											$day = $_POST['day'];
											$cat = $_POST['cat_id'];
											$attr = array(
												'cat_id'  => $cat,
												'days'	  => $day
											);
											$query = $this->db->query("SELECT * FROM `review_days` WHERE `cat_id` = '$cat' ");
											if($query->num_rows()==0){
												$this->db->insert('review_days',$attr);
												echo "<div class='alert alert-success'> Review Days inserted </div>";
											}else{
												$this->db->where('cat_id',$cat);
												$this->db->update('review_days',$attr);
												echo "<div class='alert alert-success'> Review Date Updated</div>";

											}
										}
									?>
								</div>
									<div class="col-md-5">
										<div class="panel panel-default">
											<div class="panel-heading"><div class="panel-title">Update Date</div></div>
											<div class="panel-body">
												<?php echo form_open()?>
													<?php echo form_hidden('cat_id',$this->uri->segment(3)); ?>
												<?php
													$cat = $this->uri->segment(3);
													$query = $this->db->query("SELECT * FROM `review_days` WHERE `cat_id` = '$cat' ");
													if($query->num_rows()==1){
												?>
													<div class="form-group">
														<label for="day">Date</label>
														<input type="text" placeholder="Enter Days" value="<?php echo $query->row(0)->days;?>" class="form-control" name="day">
													</div>
												<?php }else{?>
												<div class="form-group">
														<label for="day">Days</label>
														<input type="text" placeholder="Enter Days" class="form-control" name="day">
													</div>
												<?php }?>

												<div class="form-group">
													<button class="btn btn-block btn-success" name="submit">Update</button>
												</div>
												<?php echo form_close()?>
											</div>
										</div>
									</div>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>