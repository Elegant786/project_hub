<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminController extends CI_Controller {

	public function __construct(){
		parent::__construct();
		//Do your magic here
		$this->load->model('AdminModel');
		
	}

	public function index(){
		if($this->AdminModel->CheckLogin()==TRUE){
			redirect('dashboard','refresh');
		}else{
			$this->load->view('login');
		}
	}




	public function Registration(){

		$this->form_validation->set_rules('name', 'Username', 'required');
		$this->form_validation->set_rules('gender', 'Gender', 'required');		
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[admin.email]');
		$this->form_validation->set_rules('org', 'Organization', 'required');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('login');
		} else {
			if($this->AdminModel->Registration()==TRUE){
				redirect('reg-success','refresh');
			}				
		}
	}

	public function UserAdd(){

		$this->form_validation->set_rules('name', 'Username', 'required');
		$this->form_validation->set_rules('gender', 'Gender', 'required');		
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[admin.email]');
		$this->form_validation->set_rules('org', 'Organization', 'required');

		if ($this->form_validation->run() == FALSE) {
			$data = array('page' => 'new-user' );
			$this->load->view('index',$data);
		} else {
			if($this->AdminModel->Registration()==TRUE){
				redirect('dashboard/new-user?action=success','refresh');
			}else{
				redirect('dashboard/new-user?action=failed','refresh');
			}				
		}
	}

	public function EditUser(){
		if($this->AdminModel->UpdateUser()==TRUE){
			redirect('dashboard/new-user?action=updated','refresh');

		}else{
			redirect('dashboard/new-user?action=error','refresh');
		}

	}

	public function Login(){

		$this->form_validation->set_rules('password', 'Password', 'required');		
		$this->form_validation->set_rules('username', 'Username', 'required');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('login');
		}else{
			if($this->AdminModel->Login()==TRUE){
				redirect('dashboard','refresh');
			}else{
				redirect('admin-login?action=failed','refresh');
			}
		}

	}
	
	public function RegSuccess(){
		$this->load->view('reg-success');
	}

	public function Logout(){
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('name');
		$this->session->unset_userdata('level');
		$this->session->unset_userdata('password');
		$this->session->unset_userdata('uid');
		$this->session->unset_userdata('prse');
		$this->session->unset_userdata('cat');
		$this->session->unset_userdata('user_id');
		
 		$this->session->sess_destroy();
        redirect('admin-login/?logout=success');

	}

	public function NewUser(){
		
		$data = array("page"=>'new-user','title' => 'New User');
		$this->load->view('index',$data);

	}


	public function AllUsers(){
		$data = array("page"=>'all-users','title' => 'New User');
		$this->load->view('index',$data);
	}

	public function AjaxUserData(){
		$email = $_GET['email'];
		$data['users'] = $this->AdminModel->AjaxUserData($email);
		$this->load->view('pages/ajaxuser',$data);
	}

	public function MakePrecedant(){
		$str = $this->uri->segment(3);
		if($str==2){
			echo "<label>Is He/She is a Precedant ?</label> <br><input name='pre' class='' value='1' type='checkbox' /> Yes";
		}
	}

	public function RegisterNewUser(){

		$this->form_validation->set_rules('name', 'Username', 'required');
		$this->form_validation->set_rules('gender', 'Gender', 'required');		
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[admin.email]');
		

		if ($this->form_validation->run() == FALSE){
			$data = array('page' => 'new-user' );
			$this->load->view('index',$data);
		} else{

					$config = array(
				        'upload_path' => "uploads/employee",
				        'allowed_types' => "gif|jpg|png|jpeg",
				        'overwrite' => TRUE,
				        'max_size' => "2048000", 
				        
		            );
		            $this->load->library('upload', $config);
               		 $this->upload->initialize($config);

		            if(!$this->upload->do_upload('image')){

		            	$data = array('page' => 'new-user', 'upload_error' => $this->upload->display_errors());
						$this->load->view('index',$data);
		            }else{
		            	if($this->AdminModel->NewAdmin()==TRUE){
		            		redirect('dashboard/new-user?action=success','refresh');
		            	}else{
		            		redirect('dashboard/new-user?action=failed','refresh');

		            	}
		            }

			/*

				if($this->AdminModel->Registration()==TRUE){
					redirect('dashboard/new-user?action=success','refresh');
				}else{
					redirect('dashboard/new-user?action=failed','refresh');
				}

			*/
		}

	}
}

/* End of file AdminController.php */
/* Location: ./application/controllers/AdminController.php */