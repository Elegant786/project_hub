	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Other Pages</a>
							</li>
							<li class="active">Blank Page</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<h6><?php
									$cat = $this->uri->segment(4);
									$query = $this->db->query("SELECT * FROM `category` WHERE `cat_id` = '$cat' ");
									if($query->num_rows()==1){
										echo "Metarials of ".$query->row(0)->cat_name." Category";
									}
								?></h6>
									<table class="table table-responsive table-hover table-bordered">
										<thead>
											<tr>
												<th width="10">#</th>
												<th> Form ID</th>											
												<th>Submitted Date</th>											
												<th>Approximately. Approve</th>														
												<th>Status</th>
												
											</tr>
										</thead>
										<tbody id="">
													<?php
														if(isset($forms)){
															//var_dump($form);
															foreach($forms AS $row){
																@$sl++;
													?>
														<tr>
															<td><?php echo $sl;?></td>
															<td><?php echo $row->form_id?></td>
															
															<td><?php echo $row->sub_date; $sdate = $row->sub_date; ?></td>
															<td>
																
																<?php
																	if($this->session->userdata('level')==2){
																		$app = 3;
																		$appdate =  date('d-m-Y', strtotime('+3 day', strtotime($sdate)));
																	   		
																	   		$havfri = $this->DashboardModel->CountDays($sdate,$appdate,5);
																			$havSat = $this->DashboardModel->CountDays($sdate,$appdate,6);
																			if($havfri>0){
																				$app=$app+$havfri;
																			}
																			if($havSat>0){
																				$app= $app+$havSat;
																			}
																			echo date('d-m-Y', strtotime( '+'.$app.' day', strtotime($sdate)));;
																	}else{
																		echo "--";
																	}
																?>


															</td>
															<td>
																<?php
																	$sta = $row->status;
																	if($sta==1){
																		echo "<span class='label label-inverse arrowed'>Save in Drafted</span>";
																	}elseif($sta==2){
																		echo "<span class='label label-default warning'>Submited to admin</span>";
																	}elseif($sta==3){
																		echo "<span class='label label-danger warning'>Admin Disallowed</span>";
																	}elseif($sta==5){
																		echo "<span class='label label-warning warning'>Admin Approve with suggastion</span>";
																	}elseif($sta==4){
																		echo "<span class='label label-danger warning'>Approve By Admin</span>";
																	}elseif($sta==6){
																		echo "<span class='label label-danger warning'>Super Admin Disallowed</span>";
																	}elseif($sta==7){
																		echo "<span class='label label-danger warning'>Approve with suggastion By Super Admin</span>";
																	}
																	elseif($sta==8){
																		echo "<span class='label label-danger warning'>Approve By Super Admin</span>";
																	}
																?>

															</td>
															
														</tr>


													<?php } if($this->pagination->create_links()){?>
														<tr>
															<td colspan="6"><?php echo $this->pagination->create_links()?></td>
															
														</tr>

													<?php } }?>
												</tbody>
												
										
									</table>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>