	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Notification Settings</a>
							</li>
							<li class="active">All Notifications</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12">
								<?php
										if(isset($_POST['submit'])){
											$title = $_POST['title'];
											$desc = $_POST['description'];
											$date = date('d-m-Y');

											$attr = array(

												'title'   => $title,
												'details' => $desc,
												'date'    => $date,
												'status'  => 1

											);
											if($this->db->insert('notification',$attr)){
												echo "<div class='col-md-12'><div class='alert alert-success'> New Notification Added </div></div>";
											}else{
												echo "<div class='col-md-12'><div class='alert alert-danger'> New  Notification  Not Added </div></div>";

											}

										}
									?>
							
									

									<div class="col-md-5">
										<div class="panel panel-default">
											<div class="panel-heading"><div class="panel-tittle">Create Notification</div></div>
											<div class="panel-body">
												<?php echo form_open()?>
														
													<div class="form-group">
														<label>Notification Title</label>
														<input type="text" name="title" class="form-control">
													</div>

													<div class="form-group">			
														<label>Description</label>
														<textarea name="description" id="" cols="30" rows="10" class="form-control"></textarea>
													</div>

													<div class="form-group">
														<input type="submit" name="submit" class="btn btn-success ">
													</div>

												<?php echo form_close()?>
											</div>
										</div>		
									</div>
									

									
								
									
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>