	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Other Pages</a>
							</li>
							<li class="active">Blank Page</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<div class="col-md-12">
										<?php
											if(isset($_POST['submit'])){

												$action = NULL;
												$mdate = $this->input->post('mdate');
												$comment = $this->input->post('comment');
												if($this->session->userdata('level')==1){
													$type = 1;
												}else{
													$type = 0;

												}
												@$user =  $_POST['user'];
													$fid = $_POST['f_id'];
												
												
												for($i=0; $i<count(@$_POST['user']); $i++){
														$attr = array(
														'user_id' => $_POST['user'][$i],
														'form_id' => $fid
													);
													$this->db->insert('met_users',$attr);
													$action=TRUE;
												}

												if($action == TRUE){
													$attr2 = array(
														"form_id" => $fid,
														"met_date" => $mdate,
														"comments" => $comment,
														'met_from' => $type
													);
													if($this->db->insert('meeting',$attr2)){
														redirect('dashboard/user-submited-metarials','refresh');
													}
													
													}else{
														echo "<div class='alert alert-danger'> Error ! On Arranging Meeting </div>";
													}

											}
										?>
											
								</div>
									
									<div class="col-md-5">
										<div class="panel panel-default" style="border-radius: 0px;">
											<div class="panel panel-heading" style="border-radius: 0px;"><div class="panel-title">Arrange Meeting</div>
											</div>
											
											<div class="panel-body">

													<?php echo form_open();?>
														<div class="form-group">
															<label>Meeting Date</label>
															<input type="date" required="required" name="mdate" class="form-control">
															<?php echo form_hidden('f_id',$this->uri->segment(3));?>
														</div>
														<div class="form-group">
															<label>Comments</label>
															<textarea class="form-control" name="comment" rows="5"></textarea>
														</div>

														<table class="table table-bordered">
															<tr style="background-color: #f1f1f1;">
																<td>Admins</td>
															</tr>
																<?php
																	
																		$newQ = $this->db->query("SELECT * FROM `admin` WHERE `level` = 2 ");
																		$query2 = $newQ->result();
																		foreach($query2 AS $user):
																?>
																	<tr>
																		<td><input type="checkbox" name="user[]" value="<?php echo $user->user_id?>"> <?php echo $user->name?> 
																			<?php $cat = $this->db->query("SELECT * FROM `category` WHERE `cat_id` = '$user->cat_id' ");
																				echo " &nbsp ({$cat->row(0)->cat_name})";
																			 ?>
																		</td>
																	</tr>
																<?php  endforeach;?>
														</table>

														<div class="form-group">
															<input type="submit" name="submit" class="btn btn-success">
														</div>
													<?php echo form_close();?>
											</div>

										</div>
									</div>
									
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>