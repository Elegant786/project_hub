	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Profile</a>
							</li>
							<li class="active">Edit Profile</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">

							<?php
								if(isset($_POST['submit'])){
									$id =$_POST['id'];
									$name =$_POST['name'];
									$gender =$_POST['gender'];
									$org =$_POST['org'];

									$attr = array(
										'name' => $name,
										'gender' => $gender,
										'organization' => $org,

									);


									$this->db->where('user_id',$id);
									if($this->db->update('admin',$attr)){
										echo "<div class='col-md-12'><div class='alert alert-success'> profile Information Updated </div></div>";
									}else{
										echo "<div class='col-md-12'><div class='alert alert-success'> profile  Information Not Update </div></div>";
									}


								}
							?>
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
									<div class="col-md-5">
										<div class="panel panel-default">
											<div class="panel-heading"><div class="panel-title">Edit Informations</div></div>
											<div class="panel-body">
												
											<?php echo form_open()?>

												<?php 
													if($this->uri->segment(3) && $this->session->userdata('level')!=3){
														$id = $this->uri->segment(3);
													}else{
														$id = $this->session->userdata('user_id');
													}
													$query = $this->db->query("SELECT * FROM `admin` WHERE `user_id` = '$id'");
													$result = $query->result();
													foreach($result AS $user):

														echo form_hidden("id",$user->user_id);
												?>

												<fieldset>

													<label class="block clearfix">
														<span class="block input-icon input-icon-right">
															<input type="text" class="form-control" placeholder="Name" name="name" required="required" value="<?php echo $user->name;?>" />
															<i class="ace-icon fa fa-user"></i>
														</span>

													</label>

													<label class="block clearfix">
														<span class="block input-icon input-icon-right">
															<input type="email" class="form-control" placeholder="Email" required="required" value="<?php echo $user->email?>" disabled='disabled' name="email" />
															<i class="ace-icon fa fa-envelope"></i>
														</span>
													</label>

													<label class="block clearfix">
														<label>Gender</label><br>

														<?php
															if($user->gender == 0){
														?>

														<label class="inline">
															<input type="radio" class="ace" name="gender" value="1" />
															<span class="lbl"> Male</span>
														</label>

														<label class="inline">
															<input type="radio" checked="checked" class="ace" name="gender" value="2" />
															<span class="lbl"> Female</span>
														</label>
														<?php }else{?>
															<label class="inline">
															<input type="radio" checked="checked" class="ace" name="gender" value="1" />
															<span class="lbl"> Male</span>
														</label>

														<label class="inline">
															<input type="radio" class="ace" name="gender" value="2" />
															<span class="lbl"> Female</span>
														</label>
														<?php }?>

													</label>


													<label class="block clearfix">
														<span class="block input-icon input-icon-right">
															<input type="text" value="<?php echo $user->organization?>" class="form-control" name="org" placeholder="Organization Name" />
															<i class="ace-icon fa fa-home"></i>
														</span>
													</label>

													<!--<div class="form-group">
									                    <label class="control-label">Category</label>
									                    <select name="cat_id" class="form-control">
									                    		<option> SELECT CATEGORY</option>
									                    	<?php 
																$query = $this->db->get('category');
																$result = $query->result();
																foreach($result AS $row):
																	
															?>
															<option value="<?php echo $row->cat_id?>"><?php echo $row->cat_name?></option>
														<?php endforeach;?>
									                    </select>
									                </div>-->


													<div class="space-24"></div>

													<div class="clearfix">
														<button onclick="return confirm('Are You sure ?')" type="submit" name="submit" class="width-65 pull-right btn btn-sm btn-success">
															<span class="bigger-110">Register</span>

															<i class="ace-icon fa fa-arrow-right icon-on-right"></i>
														</button>
													</div>

												</fieldset>

											<?php endforeach;?>

												<?php echo form_close()?>


											</div>
										</div>
									</div>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>