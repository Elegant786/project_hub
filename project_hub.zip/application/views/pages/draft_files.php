	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Submit Metarials</a>
							</li>
							<li class="active">All Metarials</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						<div class="row" style="margin-top: 20px;">
								<div class="col-md-12">
										<table class="table table-bordered table-responsive table-hover">
												<thead>
													<tr>
														<th width="10">#</th>
														<th> Form ID</th>
														<th>Submitted Date</th>
														<th>Approximately. Approve</th>
														<th>Status</th>
														<th>Action</th>
													</tr>
												</thead>
												<tbody id="">
													<?php
														if(isset($form)){
															foreach($form AS $row){
																@$sl++;
													?>
														<tr>
															<td><?php echo $sl;?></td>
															<td><?php echo $row->form_id?></td>
															<td><?php echo $row->sub_date; $sdate = $row->sub_date; ?></td>
															<td>
																	<!-- Date Counter -->
										<span id="demo<?php echo $sl;?>"></span>
											<script>
var countDownDate = new Date("<?php echo date('M d, Y h:i:s',strtotime($row->req_date.' 12:00:00'))?>").getTime();
// Update the count down every 1 second
var x = setInterval(function() {

	// Get todays date and time
	var now = new Date().getTime();
	
	// Find the distance between now an the count down date
	var distance = countDownDate - now;
	
	// Time calculations for days, hours, minutes and seconds
	var days = Math.floor(distance / (1000 * 60 * 60 * 24));
	var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
	var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
	var seconds = Math.floor((distance % (1000 * 60)) / 1000);
	
	// Output the result in an element with id="demo"
	document.getElementById("demo<?php echo $sl;?>").innerHTML = days + "d " + hours + "h "
	+ minutes + "m " + seconds + "s ";
	
	// If the count down is over, write some text 
	if (distance < 0) {
		clearInterval(x);
		document.getElementById("demo<?php echo $sl;?>").innerHTML = "<a class='btn btn-success' href='#<?php echo base_url()?>/update/forms/review-date/'>EXPIRED</a>";
	}
}, 1000);
</script>
										

																	<!-- Date Counter -->
															</td>
															<td>
																<?php
																	$sta = $row->status;
																	if($sta==1){
																		echo "<span class='label label-inverse arrowed'>Save in Drafted</span>";
																	}elseif($sta==2){
																		echo "<span class='label label-info warning'>Submited to admin</span>";
																	}elseif($sta==3){
																		echo "<span class='label label-danger warning'>Presidant Disallowed</span>";
																	}elseif($sta==5){
																		echo "<span class='label label-warning warning'>Presidant Approve with suggastion</span>";
																	}elseif($sta==4){
																		echo "<span class='label label-danger warning'>Approve By Presidant</span>";
																	}elseif($sta==6){
																		echo "<span class='label label-danger warning'>Super Admin Approve with suggastion</span>";
																	}elseif($sta==7){
																		echo "<span class='label label-success success'>Approve By Super Admin</span>";
																	}
																	elseif($sta==8){
																		echo "<span class='label label-danger danger'>Disallowed By Super Admin</span>";
																	}
																	elseif($sta==9){
																		echo "<span class='label label-danger danger'>Presedant Review</span>";
																	}
																	elseif($sta==10){
																		echo "<span class='label label-danger danger'>Suggest By Admin</span>";
																	}
																	elseif($sta==11){
																		echo "<span class='label label-danger danger'>Disallowed By Admin</span>";
																	}
																?>

															</td>
															<td>
																
																<div class="btn-group dropup">
																	<button class="btn btn-xs btn-danger">Action</button>

																	<button <?php if($sta==7){?> disabled<?php }?> data-toggle="dropdown" class="btn btn-xs btn-danger dropdown-toggle" aria-expanded="false">
																		<span class="ace-icon fa fa-caret-down icon-only"></span>
																	</button>

																	<ul class="dropdown-menu dropdown-danger">
																		<li>
																			<a href="<?php echo base_url()?>dashboard/view-submitted/<?php echo $row->form_id?>">View / Edit</a>
																		</li>

																	<?php
																		$meeting = $this->db->query("SELECT * FROM `meeting` WHERE `form_id` = '$row->form_id'");
																		if($meeting->num_rows()==1){
																	?>
																		<li>
																			<a href="<?php echo base_url()?>dashboard/view-meetings/<?php echo $row->form_id?>">view Meeting</a>
																		</li>
																	<?php }?>
																		<li>
																			<a href="#">Something else here</a>
																		</li>

																		<li class="divider"></li>

																		<li>
																			<a href="#">Separated link</a>
																		</li>
																	</ul>
																</div>

															</td>
														</tr>


													<?php } if($this->pagination->create_links()){?>
														<tr>
															<td colspan="6"><?php echo $this->pagination->create_links()?></td>
															
														</tr>

													<?php } }?>
												</tbody>
										</table>
								</div>
						</div>
					
					</div><!-- /.page-content -->
				</div>
