					<li class="">
						<a href="<?php echo base_url()?>dashboard">
							<i class="menu-icon fa fa-tachometer"></i>
							<span class="menu-text"> Dashboard </span>
						</a>

						<b class="arrow"></b>
					</li>


					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-desktop"></i>
							<span class="menu-text"> Metarials
								
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="<?php echo base_url()?>dashboard/metarial-submission" class="">
									<i class="menu-icon fa fa-caret-right"></i>
									Submit new 
									<b class="arrow fa fa-angle-down"></b>
								</a>
							</li>

							<li class="">
								<a href="<?php echo base_url()?>dashboard/user-all-aproved" class="">
									<i class="menu-icon fa fa-caret-right"></i>
									Fully Approved
									<b class="arrow fa fa-angle-down"></b>
								</a>
							</li>

							<li class="">
								<a href="<?php echo base_url()?>dashboard/user-dis-aproved" class="">
									<i class="menu-icon fa fa-caret-right"></i>
										Close / Disallowed
									<b class="arrow fa fa-angle-down"></b>
								</a>
							</li>

							<li class="">
								<a href="<?php echo base_url()?>dashboard/my-drafted" class="">
									<i class="menu-icon fa fa-caret-right"></i>
										My Drafted
									<b class="arrow fa fa-angle-down"></b>
								</a>
							</li>

							<li class="">
								<a href="<?php echo base_url()?>dashboard/submitted-files" class="">
									<i class="menu-icon fa fa-caret-right"></i>
									Submitted Files 
									<b class="arrow fa fa-angle-down"></b>
								</a>
							</li>
						</ul>
					</li>
					