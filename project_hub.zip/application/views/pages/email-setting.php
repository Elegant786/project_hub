	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Settings</a>
							</li>
							<li class="active">Email Settings</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<?php
							if(isset($_POST['submit'])){
								
								$email = $_POST['email'];
								$pass = $_POST['pass'];
								$cc = $_POST['cc'];
								$bcc = $_POST['bcc'];

								$attr = array(
										'email_address' => $email,
										'e_pass'		=> $pass,
										'bcc' 			=> $bcc,
										'cc'  			=> $cc
									);
								
								$query = $this->db->get('email_settings');
								if($query->num_rows()==1){									
									$this->db->where('e_id',1);
									if($this->db->update('email_settings',$attr)){
										echo "<div class='col-md-12'><div class='alert alert-success'> Email  Updated </div></div>";
									}else{
										echo "<div class='col-md-12'><div class='alert alert-danger'>Error !! Email not Updated </div></div>";
									}
								}else{
									if($this->db->insert('email_settings',$attr)){
										echo "<div class='col-md-12'><div class='alert alert-success'> Email  Inserted </div></div>";
									}else{
										echo "<div class='col-md-12'><div class='alert alert-danger'>Error !! Email not Inserted </div></div>";
									}
								}

							}
						?>
						
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
									<div class="col-md-4">
										<div class="panel panel-default">
											<div class="panel-heading"><div class="panel-title">Email Settings</div></div>
											<div class="panel-body">
												<?php echo form_open()?>	
												<div class="form-group">
													<label>Email</label>
													<input name="email" type="email" class="form-control" required="required">
												</div>

												<div class="form-group">
													<label>Password</label>
													<input name="pass" type="password" class="form-control" required="required">
												</div>

												<div class="form-group">
													<label>CC</label>
													<input name="cc" type="email" class="form-control" required="required">
												</div>

												<div class="form-group">
													<label>BCC</label>
													<input name="bcc" type="email" class="form-control" required="required">
												</div>
												<div class="form-group">
													<button type="submit" name="submit" class="btn btn-block btn-success">Update Email Address</button>
												</div>
												<?php echo form_close()?>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="panel panel-default">
											<div class="panel-heading"><div class="panel-titel">Primary Email</div></div>
											<div class="panel-body">
												<table class="table table-hover table-bordered">

													<?php 
														$query = $this->db->get('email_settings');
														$result = $query->result();
														foreach ($result as $email) {
														
													?>
													<tr>
														<td>Email: <?php echo $email->email_address?> </td>
													</tr>
													<tr>
														<td>Password: <?php 

															$len = strlen($email->e_pass);
															for($i =1 ; $i<=$len; $i++){
																@$pass.="*";
															}
															echo $pass;

														 ?> </td>
													</tr>
													<tr>
														<td>CC: <?php echo $email->cc?></td>
													</tr>
													<tr>
														<td>BCC <?php echo $email->bcc;?></td>
													</tr>
													<?php }?>
												</table>

											</div>
										</div>
									</div>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>