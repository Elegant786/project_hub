	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Form Submission</a>
							</li>
							<li class="active">Confirm Submission</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div>

						<!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<?php 
								echo form_open_multipart('dashboard/edit-submission');
								$code = $this->uri->segment(3);
								$query = $this->db->query("SELECT * FROM `forms` WHERE `form_id` = '$code' ");
								$result = $query->result();
								foreach($result AS $row){
							?>
							<div class="col-xs-6">
								<div class="panel panel-default">
									<div class="panel-heading">Confirm Submission</div>
									<div class="panel-body">
										<input type="hidden" name="id" value="<?php echo $row->f_id?>">
										<input type="hidden" name="fcode" value="<?php echo $row->form_id?>">
										 <div class="form-group">
						                    <label class="control-label">Titel</label>
						                    <textarea class="form-control" required="required" name="ptype"><?php echo $row->p_type?></textarea>
						                </div>

						                <div class="form-group">
						                    <label class="control-label">Description</label>
						                    <textarea class="form-control" required="required" name="m-back"><?php echo $row->m_back?></textarea>
						                </div>

						                <div class="form-group">
						                    <label class="control-label">Comments</label>
						                    <textarea class="form-control" required="required" name="relserv"><?php echo $row->p_rel?></textarea>
						                </div>
						                <div class="form-group">
						                    <label class="control-label">Included Files</label>
						                    <textarea class="form-control" required="required" name="usermeta"><?php echo $row->wh_use?></textarea>
						                </div>

						                <div class="form-group">
						                    <label class="control-label">Tags</label>
						                    <textarea class="form-control" required="required" name="howuse"><?php echo $row->m_use?></textarea>
						                </div>
										
										<div class="form-group"><br>
											<label>Category name</label>
											<select name="category" class="form-control">
											<?php 
												$query2 = $this->db->query("SELECT * FROM `category` WHERE `cat_id` = '$row->cat_id' ");
												$result2 = $query2->result();
												foreach($result2 AS $row2):													
											?><option value="<?php echo $row2->cat_id?>"><?php echo $row2->cat_name?></option>
										<?php endforeach;?>


											<?php 
												$query3 = $this->db->query("SELECT * FROM `category` WHERE `cat_id` != '$row->cat_id' ");
												$result3 = $query3->result();
												foreach($result3 AS $row3):													
											?>
											<option value="<?php echo $row3->cat_id?>"><?php echo $row3->cat_name?></option>
										<?php endforeach;?>
												
											</select>
										</div>

										<div class="form-group">
											<label>Sub Category</label>
											<select name="sub" class="form-control">
													<?php 
														$sq1 = $this->db->query("SELECT * FROM `sub_cat` WHERE  `sub_id` = '$row->sub_cat' ");
														$sqres = $sq1->result();
														foreach ($sqres AS $sub) {
															echo "<option value='".$sub->sub_id."'>".$sub->sub_name."</option>";
														}
													?>


													<?php 
														$sq2 = $this->db->query("SELECT * FROM `sub_cat` WHERE `cat_id` = '$row->cat_id' AND `sub_id` != '$row->sub_cat' ");
														$sqres2 = $sq2->result();
														foreach ($sqres2 AS $sub2) {
															echo "<option value='".$sub2->sub_id."'>".$sub2->sub_name."</option>";
														}
													?>
											</select>

										</div>

										

										<div class="form-group">
												<div class="input_fields_wrap">
												    <button class="btn btn-success btn-xs add_field_button">Add more</button><br><br>			    
												    <div class="form-group"><input type="file" name="userFiles[]" multiple></div>
												</div><div class="clearfix" style="height:20px;"></div>

												<div class="here2">

												</div>
										</div>

										<div class="form-group">
											<label>Action</label><br>

											<?php
												 if( $row->status==5 || $row->status==6 || $row->status==1 ){
											?>

											<label class="inline">
												<input type="radio"  class="ace" name='action' value='2' />
												<span class="lbl" > Approve for submission</span>
											</label> &nbsp &nbsp
											
											<label class="inline">
												<input type="radio" checked="checked" name='action' value='1' class="ace" />
												<span class="lbl" > Save in Draft</span>
											</label>

											
											</label>
											<?php }else{?>

												<label class="inline">
												<input type="radio" checked="checked" class="ace" name='action' checked value='2' />
												<span class="lbl" > Approve for submission</span>
											</label> &nbsp &nbsp
											
											<label class="inline">
												<input type="radio" name='action' value='1' class="ace" />
												<span class="lbl" > Save in Draft</span>

											<?php }?>

										</div>

										<div class="form-group">
											<?php
												 if( $row->status==5 || $row->status==6 || $row->status==1 || $row->status==10 ){
											?>
											<input type="submit" name="update"  class="btn btn-success">
											<?php }?>
										</div>
									</div>
								</div>
							</div><!-- /.col -->

							<div class="col-xs-6">
								<table class="table table-responsive">
									<tr>
										<td colspan="3"> Uploaded Files</td>
									</tr>
										<?php
												$query4 = $this->db->select("*")
																   ->from("files")
																   ->where('form_code',$row->form_id)
																   ->get();
												$result4 = $query4->result();
												foreach($result4 AS $row4){
													@$sl++;
													$ty = explode('.',$row4->file_name);
													

													$img = array('jpg','jpeg','gif','png');
													$doc = array('doc','docx');
													$video = array('mp4','mpeg4','mov','3gp');
													$audio = array('mp3','amr','ogg');
													$pdf = array('pdf');
													

													if(in_array($ty[1],$img)){
											?>	
										<tr id="">
											<td><?php echo $sl?></td>	
											<td>
												
												<div class="col-md-12">
													<img src="<?php echo base_url()?>uploads/<?php echo $row4->file_name?>" class="img-thumbnail" alt="">
												</div>

											</td>
											<td><a href="<?php echo base_url()?>dashboard/remove-file/<?php echo $row4->form_code?>/<?php echo $row4->file_id?>"> <i class="fa fa-trash"></i> Remove</a></td>
											
										</tr>
									<?php }elseif(in_array($ty[1],$doc)){?>
										<tr><td><?php echo $sl?></td>
												
											<td>
												<div class="col-md-12">
													<img src="<?php echo base_url()?>assets/word.png" class='img-thumbnail'>
													<p>
														
														<a href="<?php echo base_url()?>dashboard/downloadFile/?file=<?php echo $row4->file_name?>" target="_blank" class='btn btn-xs btn-success' style='margin-top: 10px;'><i class='fa fa-download'></i> Download</a>
													</p>
												</div>
											</td>
											<td><a href="<?php echo base_url()?>dashboard/remove-file/<?php echo $row4->form_code?>/<?php echo $row4->file_id?>"> <i class="fa fa-trash"></i> Remove</a></td>
										</tr>

									<?php }elseif(in_array($ty[1],$video)){?>
										<tr><td><?php echo $sl?></td>												
											<td>
												<div class="col-md-12">
													<video width="400" controls>
													  <source src="<?php echo base_url()?>uploads/<?php echo $row4->file_name?>" type="video/<?php echo $ty[1]?>">													  
													  Your browser does not support HTML5 video.
													</video>
													<p>
														
														<a href="<?php echo base_url()?>dashboard/downloadFile/?file=<?php echo $row4->file_name?>" target="_blank" class='btn btn-xs btn-success' style='margin-top: 10px;'><i class='fa fa-download'></i> Download</a>
													</p>
												</div>
											</td>	
											<td><a href="<?php echo base_url()?>dashboard/remove-file/<?php echo $row4->form_code?>/<?php echo $row4->file_id?>"> <i class="fa fa-trash"></i> Remove</a></td>										
										</tr>
									<?php }elseif(in_array($ty[1],$pdf)){?>
										<tr><td><?php echo $sl?></td>												
											<td>
												<div class="col-md-12">
													<frameset cols="25%,*"> 														
														<frame src="<?php echo base_url()?>uploads/<?php echo $row4->file_name;?>" name="pdf-frame" id="pdf-frame"/> 
													</frameset>

													<p>
														
														<a href="<?php echo base_url()?>dashboard/downloadFile/?file=<?php echo $row4->file_name?>" target="_blank" class='btn btn-xs btn-success' style='margin-top: 10px;'><i class='fa fa-download'></i> Download</a>
													</p>
												</div>
											</td>
											<td><a href="<?php echo base_url()?>dashboard/remove-file/<?php echo $row4->form_code?>/<?php echo $row4->file_id?>"> <i class="fa fa-trash"></i> Remove</a></td>										
										</tr>

									<?php }elseif(in_array($ty[1],$audio)){?>

										<tr><td><?php echo $sl?></td>												
											
											<td>
												<div class="col-md-12">
													<b>Audio File</b><br>
													<audio controls>
													  <source src="<?php echo base_url()?>uploads/<?php echo $row4->file_name;?>" type="audio/<?php echo $ty[1]?>">													 
													Your browser does not support the audio element.
													</audio>

													<p>
														
														<a href="<?php echo base_url()?>dashboard/downloadFile/?file=<?php echo $row4->file_name?>" target="_blank" class='btn btn-xs btn-success' style='margin-top: 10px;'><i class='fa fa-download'></i> Download</a>
													</p>
												</div>
											</td>
											<td><a href="<?php echo base_url()?>dashboard/remove-file/<?php echo $row4->form_code?>/<?php echo $row4->file_id?>"> <i class="fa fa-trash"></i> Remove</a></td>										
										</tr>

									<?php } }?>
								</table>

								

							</div>
<?php
	if($row->status==5 || $row->status==6 || $row->status == 10 ){
?> 
<div class="col-md-12">
	<div class="col-xs-12 col-sm-6 widget-container-col ui-sortable" id="widget-container-col-8">
											<div class="widget-box widget-color-dark ui-sortable-handle" id="widget-box-8">
												<div class="widget-header">
													<h5 class="widget-title bigger lighter">Suggastons</h5>

													

													<div class="widget-toolbar">
														<div class="progress progress-mini progress-striped active pos-rel" style="width:60px;" data-percent="61%">
															<div class="progress-bar progress-bar-danger" style="width:61%"></div>
														</div>
													</div>
												</div>

													<?php
														$query2 = $this->db->query("SELECT * FROM `sug` WHERE `form_id` = '$row->f_id' ORDER BY `sug_id` DESC"); 
														$result2 = $query2->result();
														foreach($result2 AS $row2){
															@$sl1++;
													?>

												<div class="widget-body">
													<div class="widget-toolbox" id="widget-toolbox-1">
														
													</div>
													
													<div class="widget-main padding-16">
														<?php echo "(".$sl1.") ".$row2->sugg;
															if($row2->sug_by==2){
																echo "<br><br><span class='label label-inverse arrowed'> By -Admin</span>";
															}else{
																echo "<br><br><span class='label label-success arrowed'> By - Super Admin</span>";
															}
														?>
													</div>													
												</div>

												<?php }?>
											</div>
										</div>
</div>
<?php }?>

						<?php }?>
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>
<script type="text/javascript">
	function downloadFile(str) {
		
	  var xhttp;
	  if (str == "") {
	    
	    return;
	  }
	  xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
	    if (this.readyState == 4 && this.status == 200) {
	    	alert(str);
	    }
	  };
	  xhttp.open("GET", "<?php echo base_url()?>dashboard/downloadFile/?file="+str, true);
	  xhttp.send();
	}	
</script>