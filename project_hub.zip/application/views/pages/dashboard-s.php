	<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          
          ['Task', 'Final Activity'],
         
        <?php
			$id = $this->session->userdata('user_id');
			$query = $this->db->query("SELECT * FROM `forms` WHERE `status` = 7");
			if($query->num_rows()>=0){
		?>

          ['Approved ',    <?= $query->num_rows()?>],
        <?php }?>

         <?php
			$id = $this->session->userdata('user_id');
			$query = $this->db->query("SELECT * FROM `forms` WHERE `status` = 8");
			if($query->num_rows()>=0){
		?>

          ['Dis Allowed',  <?php echo $query->num_rows()?>],
          
        <?php }?>


          <?php
			$id = $this->session->userdata('user_id');
			$query = $this->db->query("SELECT * FROM `forms` WHERE `status` = 6");
			if($query->num_rows()>=0){
		?>

          ['Suggest',  <?php echo $query->num_rows()?>],
          
        <?php }?>

        ]);

        var options = {
          title: ' Activities'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>

	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Dashboard</a>
							</li>
							<li class="active">Super Admin</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->

						
					</div>

					<div class="page-content">
							
						<!-- chart 1 -->


							<div class="col-md-7 infobox-container">
										<?php
											$id = $this->session->userdata('user_id');
											$query = $this->db->query("SELECT * FROM `forms` ");
											if($query->num_rows()>=0){
										?>

										<div class="infobox infobox-green">
											<div class="infobox-icon">
												<i class="ace-icon fa fa-comments"></i>
											</div>
											<div class="infobox-data">
												<span class="infobox-data-number"><?php echo $query->num_rows();?></span>
												<div class="infobox-content">Total Submited</div>
											</div>
										</div>

										<?php }?>

										<?php
											$id = $this->session->userdata('user_id');
											$query = $this->db->query("SELECT * FROM `forms` WHERE  `status` = '1' ");
											if($query->num_rows()>=0){
										?>

										<div class="infobox infobox-blue">
											<div class="infobox-icon">
												<i class="ace-icon fa fa-twitter"></i>
											</div>

											<div class="infobox-data">
												<span class="infobox-data-number"><?php echo $query->num_rows();?></span>
												<div class="infobox-content">On Draft</div>
											</div>
										</div>

										<?php }?>
										
										<?php
											$id = $this->session->userdata('user_id');
											$query = $this->db->query("SELECT * FROM `forms` WHERE `status` = '2' ");
											if($query->num_rows()>=0){
										?>
										<div class="infobox infobox-pink">
											<div class="infobox-icon">
												<i class="ace-icon fa fa-shopping-cart"></i>
											</div>

											<div class="infobox-data">
												<span class="infobox-data-number"><?php echo $query->num_rows();?></span>
												<div class="infobox-content">Admin Review</div>
											</div>
											
										</div>

									<?php }?>
										<?php
											$id = $this->session->userdata('user_id');
											$query = $this->db->query("SELECT * FROM `forms` WHERE  `status` = '9' ");
											if($query->num_rows()>=0){
										?>
										<div class="infobox infobox-red">
											<div class="infobox-icon">
												<i class="ace-icon fa fa-flask"></i>
											</div>

											<div class="infobox-data">
												<span class="infobox-data-number"><?= $query->num_rows()?></span>
												<div class="infobox-content"> Presedant Review</div>
											</div>
										</div>
										<?php }?>
										<?php
											$id = $this->session->userdata('user_id');
											$query = $this->db->query("SELECT * FROM `forms` WHERE  `status` = '3' ");
											if($query->num_rows()>=0){
										?>
										
										<div class="infobox infobox-orange2">
											<div class="infobox-chart">
												<span class="sparkline" data-values="196,128,202,177,154,94,100,170,224"><canvas width="44" height="33" style="display: inline-block; width: 44px; height: 33px; vertical-align: top;"></canvas></span>
											</div>

											<div class="infobox-data">
												<span class="infobox-data-number"><?php echo $query->num_rows() ?></span>
												<div class="infobox-content">Presedant disallow</div>
											</div>
										</div>
										<?php }?>
										
										<?php
											$id = $this->session->userdata('user_id');
											$query = $this->db->query("SELECT * FROM `forms` WHERE `status` = '8' ");
											if($query->num_rows()>=0){
										?>
										

										<div class="infobox infobox-blue2">
											<div class="infobox-progress">
												<div class="easy-pie-chart percentage" data-percent="42" data-size="46" style="height: 46px; width: 46px; line-height: 45px;">
													
												<canvas height="46" width="46"></canvas></div>
											</div>

											<div class="infobox-data">
												<span class="infobox-text"><?php echo $query->num_rows()?></span>

												<div class="infobox-content">												
													disabled super admin
												</div>
											</div>
										</div>

										<?php }?>

										<div class="space-6"></div>
										
										<?php
											$id = $this->session->userdata('user_id');
											$query = $this->db->query("SELECT * FROM `forms` WHERE  `status` = '4' ");
											if($query->num_rows()>=0){
										?>

										<div class="infobox infobox-orange infobox-small infobox-dark">
											<div class="infobox-progress">
												<div class="easy-pie-chart percentage" data-percent="61" data-size="39" style="height: 39px; width: 39px; line-height: 38px;">
													<span class="percent"><?php echo $query->num_rows() ?></span>
												<canvas height="39" width="39"></canvas></div>
											</div>

											<div class="infobox-data">
												<div class="infobox-content">Super Admin</div>
												<div class="infobox-content"> Review</div>
											</div>
										</div>
										<?php }?>
										
										<?php
											$id = $this->session->userdata('user_id');
											$query = $this->db->query("SELECT * FROM `forms` WHERE `status` = '7' ");
											if($query->num_rows()>=0){
										?>
										<div class="infobox infobox-blue infobox-small infobox-dark">
											<div class="infobox-chart">
												<span class="sparkline" data-values="3,4,2,3,4,4,2,2"><canvas width="39" height="19" style="display: inline-block; width: 39px; height: 19px; vertical-align: top;"></canvas></span>
											</div>

											<div class="infobox-data">
												<div class="infobox-content">Approved</div>
												<div class="infobox-content"><?= $query->num_rows()?></div>
											</div>
										</div>
										<?php }?>
									</div>

						 <!-- Chart End -->

						 <div class="col-md-5">
								<div id="piechart"></div>
						 </div>
					</div>
						
<div class="col-md-12" style="margin-top: 10px;">
	<?php 
		$query = $this->db->get('category');
		$result = $query->result();
		foreach($result AS $row){
	?>
	<div class="col-md-3">
		<table class="table table-bordered">
			
			<thead><tr ><td style="background-color:#F1F1F1; " colspan='2'><?php echo $row->cat_name?></td></tr></thead>
			<tr>
				<td>Total</td>
				<td>
					<?php 
						$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$row->cat_id' AND `status` != 1");
						echo $query->num_rows();
					?>
				</td>				
			</tr>
			<tr>
				<td>Admin Review</td>
				<td>
					<?php 

						$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$row->cat_id' AND `status` = 2");
						echo $query->num_rows();
					?>
				</td>				
			</tr>
			
			<tr>
				<td>Approved By Admin</td>
				<td>
					<?php 
						$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$row->cat_id' AND `status` = 9");
						echo $query->num_rows();
					?>
				</td>				
			</tr>

			<tr>
				<td>Disallow By Admin</td>
				<td>
					<?php 
						$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$row->cat_id' AND `status` = 11");
						echo $query->num_rows();
					?>
				</td>				
			</tr>

			<tr>
				<td>Approve By  Presedant</td>
				<td>
					<?php 
						$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$row->cat_id' AND `status` = 4");
						echo $query->num_rows();
					?>
				</td>				
			</tr>

			<tr>
				<td>Disallow By  Presedant</td>
				<td>
					<?php 
						$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$row->cat_id' AND `status` = 3");
						echo $query->num_rows();
					?>
				</td>				
			</tr>

			<tr>
				<td>Approve by Super Admin</td>
				<td>
					<?php 
						$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$row->cat_id' AND `status` = 7");
						echo $query->num_rows();
					?>					
				</td>				
			</tr>

			<tr>
				<td>Disallow By Super Admin</td>
				<td>
					<?php 
						$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$row->cat_id' AND `status` = 8");
						echo $query->num_rows();
					?>
				</td>				
			</tr>

		</table>

	</div>
	<?php }?>
</div>
					
					</div><!-- /.page-content -->
				</div>