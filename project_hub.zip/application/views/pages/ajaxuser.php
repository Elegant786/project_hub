<?php
	if(isset($users)):
		foreach($users AS $row):
?>
<label class="block clearfix">
	<label>Name</label><br>
	<span class="block input-icon input-icon-right">
		<input type="text" class="form-control" value="<?php echo $row->name;?>" name="name" required="required" />
		<i class="ace-icon fa fa-user"></i>
	</span>
</label>

<?php
	if($row->gender==1){
?>

<label class="block clearfix">
	<label>Gender</label><br>
	<label class="inline">
		<input type="radio" class="ace" checked="checked" name="gender" value="1" />
		<span class="lbl"> Male</span>
	</label>

	<label class="inline">
		<input type="radio" class="ace" name="gender" value="2" />
		<span class="lbl"> Female</span>
	</label>
</label>
<?php }else{?>

<label class="block clearfix">
	<label>Gender</label><br>
	<label class="inline">
		<input type="radio" class="ace" name="gender" value="1" />
		<span class="lbl"> Male</span>
	</label>

	<label class="inline">
		<input type="radio" checked="checked" class="ace" name="gender" value="2" />
		<span class="lbl"> Female</span>
	</label>
</label>

<?php }?>

<label class="block clearfix">
	<label>Organization Name</label><br>
	<span class="block input-icon input-icon-right">
		<input type="text" class="form-control" value="<?php echo $row->organization?>" name="org" />
		<i class="ace-icon fa fa-home"></i>
	</span>
</label>

<div class="form-group">
        <label class="control-label">Category</label>
        <select name="cat_id" class="form-control">

        	<?php 
				$query2 = $this->db->query("SELECT * FROM `category` WHERE `cat_id` = '".$row->cat_id."'");
				$result2 = $query2->result();
				foreach($result2 AS $row2):
					
			?>
			<option value="<?php echo $row2->cat_id?>"><?php echo $row2->cat_name?></option>
			<?php endforeach;?>
        		
        	<?php 
				$query3 = $this->db->query("SELECT * FROM `category` WHERE `cat_id` != '".$row->cat_id."'");
				$result3 = $query3->result();
				foreach($result3 AS $row3):
					
			?>
			<option value="<?php echo $row3->cat_id?>"><?php echo $row3->cat_name?></option>
		<?php endforeach;?>
        </select>
</div>

<?php
	endforeach; endif;
?>