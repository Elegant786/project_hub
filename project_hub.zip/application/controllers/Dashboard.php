<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('AdminModel');
		$this->load->model('DashboardModel');
		$this->load->helper('download');
		$this->load->library('pagination');
		if($this->AdminModel->CheckLogin()==FALSE){
			redirect('admin-login?action=no-session');
		}
	}

	public function index(){
        if($this->session->userdata('level')==3){
            $page = 'dashboard-u';
        }elseif ($this->session->userdata('level')==1) {
             $page = 'dashboard-s';
        }elseif ($this->session->userdata('level')==2 && $this->session->userdata('prse')==1) {
             $page = 'dashboard-p';
        }elseif ($this->session->userdata('level')==2 && $this->session->userdata('prse')==0) {
             $page = 'dashboard-a';
        }
		$data = array(
			'page' => $page,
			'title' => 'Dashboard '
		);
		$this->load->view('index',$data);
	}


# Category & SubCategory

	public function Category(){
		$data = array(
			'page' => 'category',
			'title' => 'Dashboard | Create Category '
		);
		$this->load->view('index',$data);
	}

    public function AddSubCategory(){
        $data = array(
            'page' => 'sub-category',
            'title' => 'Dashboard | Create Sub category '
        );
        $this->load->view('index',$data);
    }

    public function EditSubCategory(){
        $data = array(
            'page' => 'sub-category',
            'title' => 'Dashboard | Create Sub category '
        );
        $this->load->view('index',$data);
    }

    public function SubDelete(){
        $sub = $_GET['sub'];
        $cat = $_GET['cat'];

        $query = $this->db->query("DELETE FROM `sub_cat` WHERE `sub_id` = '$sub'");
        redirect('dashboard/sub-category/add-new/'.$cat,'refresh');
    }

    public function SelectAdmin(){
        $data = array(
            'page' => 'select-admin',
            'title' => 'Dashboard | Create Category '
        );
        $this->load->view('index',$data);
    }

	public function EditCategory(){
		$data = array(
			'page' => 'category',
			'title' => 'Dashboard | Edit Category '
		);
		$this->load->view('index',$data);
	}

	public function DeleteCategory(){
		$id = $this->uri->segment(4);
		$this->db->query("DELETE FROM `category` WHERE `cat_id` = '$id' ");
		redirect('dashboard/new-category','refresh');
	}

    public function AddPrecedant(){
        $data = array('page' => 'select-prese');
        $this->load->view('index',$data);
    }

    public function SubAdmins(){
        $data = array("page" => 'set-admin');
        $this->load->view('index',$data);
    }

// End of Subcategory

    public function ViewFormCateogry(){
         $cat = $this->uri->segment(4);
        
        $num =$this->DashboardModel->CountCatForms($cat);
            $config=array(

                    'base_url'           =>     base_url('dashboard/view-forms/category/'.$cat),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>',
                    );

            
        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetCatForms($cat ,$config['per_page'], $this->uri->segment(5));
        $data = array('page' => "cat-forms","forms" => $result);
        $this->load->view('index',$data);
    }




#Metarials Submission

	public function MetarialSubmission(){
		$data = array(
			'page' => 'meta-submission',
			'title' => 'Dashboard | Metarials Submission '
		);		
		$this->load->view('index',$data);
	}
//user Upload New Metarials
	public function UploadMetarials(){
		
		$filesCount = count($_FILES['userFiles']['name']);
            for($i = 0; $i < $filesCount; $i++){
                $_FILES['userFile']['name'] = $_FILES['userFiles']['name'][$i];
                $_FILES['userFile']['type'] = $_FILES['userFiles']['type'][$i];
                $_FILES['userFile']['tmp_name'] = $_FILES['userFiles']['tmp_name'][$i];
                $_FILES['userFile']['error'] = $_FILES['userFiles']['error'][$i];
                $_FILES['userFile']['size'] = $_FILES['userFiles']['size'][$i];

                $uploadPath = 'uploads/';
                $config['upload_path'] = $uploadPath;
                $config['allowed_types'] = 'avi|mp4|flv|doc|docx|jpg|png|pdf|PDF|JPG|JPEG|AVI|MP4|3gp|GIF|gif|mp3|mov|aac|m4a|amr|ogg|rtf|txt|zip|rar';
                $config['encrypt_name'] = FALSE;
               // $config['max_size'] = 
                
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                if($this->upload->do_upload('userFile')){
                    $fileData = $this->upload->data();
                    $uploadData[$i]['file_name'] = $fileData['file_name'];
                    $uploadData[$i]['created'] = date("Y-m-d H:i:s");
                    $uploadData[$i]['modified'] = date("Y-m-d H:i:s");

                    		$attr = array(
							'form_code' => $_POST['fcode'],
							'file_name' => $uploadData[$i]['file_name']
						);

						if($this->db->insert('files',$attr)==TRUE){
							$action = TRUE;
						}else{
							$action = FALSE;
						}

                }else{
                	print_r($this->upload->display_errors());
                }
            }

            if($action == TRUE){
            	if($this->DashboardModel->SubmitData()==TRUE){
            		redirect('dashboard/view-submitted/'.$_POST['fcode'],'refresh');
            	}else{
            		redirect('dashboard/metarial-submission?action=failed','refresh');
            	}
            }else{
            	redirect('dashboard/metarial-submission?action=failed','refresh');
            }
            
          
    }

#Update Files
    public function UpdateSubmittedForm(){
		$filesCount = count($_FILES['userFiles']['name']);
			if($_FILES['userFiles']['name'] != ''){
            for($i = 0; $i < $filesCount; $i++){
                $_FILES['userFile']['name'] = $_FILES['userFiles']['name'][$i];
                $_FILES['userFile']['type'] = $_FILES['userFiles']['type'][$i];
                $_FILES['userFile']['tmp_name'] = $_FILES['userFiles']['tmp_name'][$i];
                $_FILES['userFile']['error'] = $_FILES['userFiles']['error'][$i];
                $_FILES['userFile']['size'] = $_FILES['userFiles']['size'][$i];

                $uploadPath = 'uploads/';
                $config['upload_path'] = $uploadPath;
                $config['allowed_types'] = 'avi|mp4|flv|doc|docx|jpg|png|pdf|PDF|JPG|JPEG|AVI|MP4|3gp|GIF|gif|mp3|mov|aac|m4a|amr|ogg|rtf|txt|zip|rar';
                $config['encrypt_name'] = FALSE;
                
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                if($this->upload->do_upload('userFile')){
                    $fileData = $this->upload->data();
                    $uploadData[$i]['file_name'] = $fileData['file_name'];
                    $uploadData[$i]['created'] = date("Y-m-d H:i:s");
                    $uploadData[$i]['modified'] = date("Y-m-d H:i:s");

                    		$attr = array(
							'form_code' => $_POST['fcode'],
							'file_name' => $uploadData[$i]['file_name']
						);
                    $this->db->insert('files',$attr);
						/*if($this->db->insert('files',$attr)==TRUE){
							$action = TRUE;
						}else{
							$action = FALSE;
						}*/
						$action =TRUE;
                }else{
                	$action =TRUE;
                	//print_r($this->upload->display_errors());
                }

            }

            if($action == TRUE){
            	if($this->DashboardModel->UpdateForm()==TRUE){
            		//redirect('dashboard/view-submitted/'.$_POST['fcode'].'?action=success','refresh');
            	}else{
            		//redirect('dashboard/view-submitted/'.$_POST['fcode'].'?action=success','refresh');
            	}
            }else{
            	//redirect('dashboard/view-submitted/'.$_POST['fcode'].'?action=success','refresh');
            }
          }else{
          	if($action == TRUE){
            	if($this->DashboardModel->UpdateForm()==TRUE){
            		//redirect('dashboard/view-submitted/'.$_POST['fcode'].'?action=success','refresh');
            	}else{
            		//redirect('dashboard/view-submitted/'.$_POST['fcode'].'?action=success','refresh');
            	}
            }else{
            	//redirect('dashboard/view-submitted/'.$_POST['fcode'].'?action=success','refresh');
            }
          }
	redirect('dashboard/view-submitted/'.$_POST['fcode'].'?action=success','refresh');
 }

#Submitted Files

    public function SubmittedFiles(){
    	
    	$num =$this->DashboardModel->CountForms();
			$config=array(

					'base_url' 			 =>		base_url('dashboard/submitted-files'),
					'per_page' 			 =>		15,
					'total_rows'		 => 	$num,
					'full_tag_open' 	 =>		'<ul class="pagination pagination-sm no-margin pull-right">',
					'full_tag_close'	 => 	'</ul>',
					'first_tag_open'	 => 	'<li>',
					'first_tag_close'	 => 	'</li>',
					'last_tag_open' 	 => 	'<li>',
					'last_tag_close' 	 => 	'</li>',
					'next_tag_open' 	 => 	'<li>',
					'next_tag_close'	 => 	'</li>', 
					'prev_tag_open' 	 => 	'<li>',
					'prev_tag_close' 	 => 	'</li>',
					'num_tag_open'       => 	'<li>',
					'num_tag_close' 	 => 	'</li>',
					'cur_tag_open'  	 => 	'<li class="active"> <a>',
					'cur_tag_close'  	 => 	'</a></li>',
					);

			
		$this->pagination->initialize($config);
		$result=$this->DashboardModel->GetFroms($config['per_page'], $this->uri->segment(3));



    	$data = array('page' => 'submitted-metarials', 'title' => 'Dashboard | Submitted Metarials','form' => $result);
    	$this->load->view('index',$data);
    }


    public function UserSubmitedMeta(){
    	$num =$this->DashboardModel->CoundAdminAllowed();
			$config=array(

					'base_url' 			 =>		base_url('dashboard/user-submited-metarials'),
					'per_page' 			 =>		15,
					'total_rows'		 => 	$num,
					'full_tag_open' 	 =>		'<ul class="pagination pagination-sm no-margin pull-right">',
					'full_tag_close'	 => 	'</ul>',
					'first_tag_open'	 => 	'<li>',
					'first_tag_close'	 => 	'</li>',
					'last_tag_open' 	 => 	'<li>',
					'last_tag_close' 	 => 	'</li>',
					'next_tag_open' 	 => 	'<li>',
					'next_tag_close'	 => 	'</li>', 
					'prev_tag_open' 	 => 	'<li>',
					'prev_tag_close' 	 => 	'</li>',
					'num_tag_open'       => 	'<li>',
					'num_tag_close' 	 => 	'</li>',
					'cur_tag_open'  	 => 	'<li class="active"> <a>',
					'cur_tag_close'  	 => 	'</a></li>',
					);

			
		$this->pagination->initialize($config);
		$result=$this->DashboardModel->GetAdminAllowed($config['per_page'], $this->uri->segment(3));
    	$data = array('page' => 'new-submited', 'title' => 'Dashboard | Submitted Metarials','form' => $result);
    	$this->load->view('index',$data);
    }


    public function DisallowedSubmission(){
    	$num =$this->DashboardModel->CountAdminDisallowed();
			$config=array(

					'base_url' 			 =>		base_url('dashboard/user-submited-metarials'),
					'per_page' 			 =>		15,
					'total_rows'		 => 	$num,
					'full_tag_open' 	 =>		'<ul class="pagination pagination-sm no-margin pull-right">',
					'full_tag_close'	 => 	'</ul>',
					'first_tag_open'	 => 	'<li>',
					'first_tag_close'	 => 	'</li>',
					'last_tag_open' 	 => 	'<li>',
					'last_tag_close' 	 => 	'</li>',
					'next_tag_open' 	 => 	'<li>',
					'next_tag_close'	 => 	'</li>', 
					'prev_tag_open' 	 => 	'<li>',
					'prev_tag_close' 	 => 	'</li>',
					'num_tag_open'       => 	'<li>',
					'num_tag_close' 	 => 	'</li>',
					'cur_tag_open'  	 => 	'<li class="active"> <a>',
					'cur_tag_close'  	 => 	'</a></li>'

					);

			
		$this->pagination->initialize($config);
		$result=$this->DashboardModel->GetAdminDisallowed($config['per_page'], $this->uri->segment(3));
    	$data = array('page' => 'dis-allowed', 'title' => 'Dashboard | Disallowed Forms','form' => $result);
    	$this->load->view('index',$data);
    }


    public function AdminSuggastionsForms(){
        $num =$this->DashboardModel->CountAdminsSuggForms();
            $config=array(

                    'base_url'           =>     base_url('dashboard/admin-suggastions-forms'),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>'

                    );

            
        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetAdminsSuggForms($config['per_page'], $this->uri->segment(3));
        $data = array('page' => 'admin_sug_fomrs', 'title' => 'Dashboard | Disallowed Forms','form' => $result);
        $this->load->view('index',$data);

    }

    public function PresedantReviedForms(){
        $num =$this->DashboardModel->CountPresedantReview();
            $config=array(

                    'base_url'           =>     base_url('dashboard/presedant-review-forms'),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>'

                    );

            
        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetPresedantReview($config['per_page'], $this->uri->segment(3));
        $data = array('page' => 'all-mets', 'title' => 'Dashboard | Disallowed Forms','form' => $result);
        $this->load->view('index',$data);
    }


    public function AllMetas(){
        $num =$this->DashboardModel->AllMetaCount();
            $config=array(

                    'base_url'           =>     base_url('dashboard/user-submited-metarials'),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>',
                    );

        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetAllMeta($config['per_page'], $this->uri->segment(3));
        $data = array('page' => 'all-mets', 'title' => 'Dashboard | Disallowed Forms','form' => $result);
        $this->load->view('index',$data);
    }


    public function AdminAllMetas(){
        $num =$this->DashboardModel->AdminAllMetaCount();
            $config=array(

                    'base_url'           =>     base_url('dashboard/user-submited-metarials'),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>',
                    );

        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetAdminAllMeta($config['per_page'], $this->uri->segment(3));
        $data = array('page' => 'admin-all-mets', 'title' => 'Dashboard | Disallowed Forms','form' => $result);
        $this->load->view('index',$data);
    }

    public function FullyApprovedUser(){
        $num =$this->DashboardModel->UserFullyApproveCount();
            $config=array(

                    'base_url'           =>     base_url("dashboard/user-all-aproved"),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>',
                    );

        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetFullyApproveCount($config['per_page'], $this->uri->segment(3));
        $data = array('page' => 'admin-all-mets', 'title' => 'Dashboard | Approved Forms','form' => $result);
        $this->load->view('index',$data);

    }

    public function UserDisallowed(){
         $num =$this->DashboardModel->UserDisallowedCount();
            $config=array(

                    'base_url'           =>     base_url("dashboard/user-dis-aproved"),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>',
                    );

        $this->pagination->initialize($config);
        $result=$this->DashboardModel->UserDisallowedGet($config['per_page'], $this->uri->segment(3));

        $data = array('page' => 'draft_files', 'title' => 'Dashboard | Disallowed Forms','form' => $result);
        $this->load->view('index',$data);
    }

    public function MyDrafted(){
         $num =$this->DashboardModel->MyDraftedCount();
            $config=array(

                    'base_url'           =>     base_url("dashboard/user-dis-aproved"),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>',
                    );

        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetMyDrafted($config['per_page'], $this->uri->segment(3));

        $data = array('page' => 'draft_files', 'title' => 'Dashboard | Disallowed Forms','form' => $result);
        $this->load->view('index',$data);
    }

    public function RemoveFile(){
    	 $fcode = $this->uri->segment(3);
    	$fid = $this->uri->segment(4);
    	$query = $this->db->query("DELETE FROM `files` WHERE `file_id` = '$fid' ");
    	redirect('dashboard/view-submitted/'.$fcode,'refresh');
    }

    public function ViewSubmitted(){
    	$data = array('page' => 'view-sumitted');
    	$this->load->view('index',$data);
    } 

    public function AjaxFormGet(){
    	$id =$this->uri->segment(3);
    	
    	$data['data'] = $this->DashboardModel->AjaxForms($id); 
    	$this->load->view('pages/ajaxforms',$data);
    }

    public function DownloadFile(){
    	$file =	$_GET['file'];
    	force_download('uploads/'.$file,null);
    	return true;
    }


    public function ViewMetarials(){
    	$data = array('page' => 'view-materials','title' => "View Metarials");
    	$this->load->view('index',$data);
    }

    public function ApprovedFrom(){

    	$f_id = $this->uri->segment(3);

    	$attr = array('status'=>4, 'p_user' => $this->session->userdata('user_id'));

        if($this->session->userdata('level')==2 && $this->session->userdata('prse')==0){

            $query = $this->db->query("SELECT * FROM `app_forms` WHERE `form_id` = '$f_id' ");
            if($query->num_rows()==0){

            $attr = array('status'=>9, 'p_user' => $this->session->userdata('user_id'));
            $attr2 = array('user_id' => $this->session->userdata('user_id'), 'form_id' => $f_id,'status' => 1);
            $this->db->insert('app_forms',$attr2);
        }else{
            $attr = array('status'=>9, 'p_user' => $this->session->userdata('user_id'));
            $attr2 = array('user_id' => $this->session->userdata('user_id'), 'form_id' => $f_id,'status' => 1);
            $this->db->where('form_id',$f_id);
            $this->db->update('app_forms',$attr2);
        }
        
        }
        $this->db->where('f_id',$f_id);
        $this->db->update('forms',$attr);
    	redirect('dashboard/view-materials/'.$f_id,'refresh');
    }

    public function DisallowedForm(){
    	$f_id = $this->uri->segment(3);
    	$attr = array('status'=>3);

        //Notification
            $query = $this->db->query("SELECT * FROM `forms` WHERE `f_id` = '$f_id'");
            $subject = "Form Disallowed By Admin";
            $message = "Your form has been Disallowed by Admin, disallowed form id =".$query->row(0)->form_id;
            $uid = $query->row(0)->user_id;
            $noti = array(
                'user_id' => $uid,
                'subject' => $subject,
                'massage' => $message,
                'status'  => 1 
            );
            $this->db->insert('user_notification',$noti);
        //Notification End

        if($this->session->userdata('level')==2 && $this->session->userdata('prse')==0){
            $attr = array('status'=>11 , 'p_user' => $this->session->userdata('user_id'));
            $attr2 = array('user_id' => $this->session->userdata('user_id'), 'form_id' => $f_id,'status' => 3);
            $this->db->insert('app_forms',$attr2);
        }
    	$this->db->where('f_id',$f_id);
    	$this->db->update('forms',$attr);       
    	redirect('dashboard/view-materials/'.$f_id,'refresh');

    }

    public function ApprovedSuggastions(){
    	$data = array(
    		'page' => 'suggest-form',
    		'title' => "Form Suggastions"
    	 );

    	$this->load->view('index',$data);

    }

    public function SuperAdminApprove(){
        
        $f_id = $this->uri->segment(3);
        $attr = array('status'=>7);
        $this->db->where('f_id',$f_id);
        $this->db->update('forms',$attr);
        /*
            
            $this->load->library('email');
            $this->email->from('rahman@eleganttechbd.com', 'Abdur Rahaman');
            $this->email->to($email);
            $this->email->cc('salam@eleganttechbd.com');
            $this->email->bcc('tamal@eleganttechbd.com');               
            $this->email->subject('Registration Compleate Successfully');
            $message = "Thank You for Registration. Your User Id = ".$uid." Email is ".$email." Password= ".$pass;
            $this->email->message($message);        
            $this->email->send();

        */
        redirect('dashboard/view-materials/'.$f_id,'refresh');
    }


    public function SuperDisallowed(){
        $f_id = $this->uri->segment(3);
        $attr = array('status'=>8);
        $this->db->where('f_id',$f_id);
        $this->db->update('forms',$attr);
       //Notification Start
        $query = $this->db->query("SELECT * FROM `forms` WHERE `f_id` = '$f_id'");
        $result = $query->result();
       
        $subject = "Form Disallowed By Super Admin";
        $message = "Your form has been Disallowed by Super Admin, disallowed form id: ".$query->row(0)->form_id;
        $uid = $query->row(0)->user_id;
        $noti = array(
            'user_id' => $uid,
            'subject' => $subject,
            'massage' => $message,
            'status'  => 1 
        );
        $this->db->insert('user_notification',$noti);
    // notification End

        redirect('dashboard/view-materials/'.$f_id,'refresh');
    }


    public function ArrangeMeeting(){
        $data = array(
            "page" => 'arrange-meeting'
        );
        $this->load->view('index',$data);

    }

    public function ViewMeeting(){
        $data = array('page' => 'met-details');
        $this->load->view('index',$data);
    }

    #profile

    public function Profile(){
        $data = array('page' => 'profile');
        $this->load->view('index',$data);
    }

    public function EditProfile(){
        $data = array('page' => 'edit-profile');
        $this->load->view('index',$data);
    }


    public function ProfileSetting(){
            $data = array('page' => 'profile-settings');
            $this->load->view('index',$data);
        }

    public function uploadSignature(){
            $config['upload_path']          = 'uploads/sign';
            $config['allowed_types']        = 'gif|jpg|png|PNG|GIF|JPG|JPEG';
            $config['max_size']             = 1000;
            $this->load->library('upload', $config);

            if ( ! $this->upload->do_upload('image'))        {
                    $error = array('page' => 'profile-settings','error' => $this->upload->display_errors());
                    $this->load->view('index', $error);
            }else{
                $attr = array("sig" => $this->upload->data('file_name'));
                    $this->db->where('user_id',$_POST['uid']);
                    $this->db->update('signatures',$attr);
                redirect('dashboard/profile-settings?action=success','refresh');

            }
    }

    public function AppEmailSettings(){
        $data = array('page' => 'email-setting');
        $this->load->view('index',$data);
    }


#Chatting

    public function UserChatting(){
        $sender = $this->session->userdata('user_id');
        $reciver = $this->uri->segment(4);
        $update = $this->db->query(" UPDATE `chat` SET `status` = 2 WHERE  (`sender`, `reciver`) IN (('$sender', '$reciver'), ('$reciver','$sender'))");
        $data = array("page" => 'user-chat');
        $this->load->view('index',$data);
    }


    public function AllMassages(){
        $data = array("page" => 'chat-rooms');
        $this->load->view('index',$data);
    }

    public function AjaxMsgSend(){


         $sender = $_GET['sender'];
         $reciver = $_GET['reciver'];
         $update = $this->db->query(" UPDATE `chat` SET `status` = 2 WHERE  (`sender`, `reciver`) IN (('$sender', '$reciver'), ('$reciver','$sender')) ");        
         
         $msg = $_GET['msg'];
         $attr = array(
            'sender'  => $sender,
            'reciver' => $reciver,
            'massage' => $msg,
            'time'    => date('d-m-y h:i:s'),
            'status'  => 1

         );
         if($this->db->insert('chat',$attr)){
            $data = array(
                "sender" => $sender,
                "reciver" => $reciver
            );
            $this->load->view('pages/get-msg',$data);
         }


    }
#Notification Module
    public function Notifications(){
        $data = array(
            'page'   => 'notifications'
        ); 
        $this->load->view('index',$data);
    }

    public function AdminsNotifications(){
        $num =$this->DashboardModel->AdminNotificationsCount();
            $config=array(

                    'base_url'           =>     base_url('dashboard/view-admin-notifications'),
                    'per_page'           =>     10,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>',
                    );

        $this->pagination->initialize($config);
        $result=$this->DashboardModel->AllAdminNotifications($config['per_page'], $this->uri->segment(3));

        $data = array( 'page' => 'all-notifi-admin', 'data' => $result );
        $this->load->view('index',$data);
    }

    public function ShowNotic(){

        if($this->session->userdata('level')==2 && $this->session->userdata('prse')==0){
            $id = $this->uri->segment(4);
            $query = $this->db->query("UPDATE `admin_notice` SET `status` = 2 WHERE  `notice_id` ='$id' ");
        }else{

            $id = $this->uri->segment(4);
            $query = $this->db->query("UPDATE `notification` SET `status` = 2 WHERE  `notif_id` ='$id' ");
        }

        $data = array('page' => 'show-notic' );
        $this->load->view('index',$data);
    }

    public function ShowUserNotic(){
        $id = $this->uri->segment(5);
        $this->db->where('notif_id',$id);
        $this->db->update('user_notification',array('status' => 2));

        $data = array('page' => 'show-notic-user' );
        $this->load->view('index',$data);
    }

    public function FormReviewDate(){
        $data = array( 'page' => 'form-date' );
        $this->load->view('index',$data);
    }

    public function UserNotificcation(){
        $data = array( 'page' => 'user-noti');
        $this->load->view('index',$data);
    }

    public function AllNotification(){

        $num =$this->DashboardModel->CountNotification();
            $config=array(

                    'base_url'           =>     base_url('dashboard/all-notifications'),
                    'per_page'           =>     10,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>',
                    );

        $this->pagination->initialize($config);
        $result=$this->DashboardModel->AllNotification($config['per_page'], $this->uri->segment(3));

        $data = array( 'page' => 'all-notification', 'data' => $result );
        $this->load->view('index',$data);
    }
    
#End Of File
}

/* End of file Dashboard.php */
/* Location: ./application/controllers/Dashboard.php */