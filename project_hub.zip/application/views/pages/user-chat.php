	
	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>
							<li class="active">Chating</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								
								<?php
									if($this->uri->segment(4)){
									$uri = $this->uri->segment(4);
									$usq = $this->db->query("SELECT * FROM `admin` WHERE `user_id` = '$uri' ");
									echo "<a href='#' class='btn btn-success'>".$usq->row(0)->name."</a>";
								}
								?>

							</div>
						<div class="col-md-5" id="msgg" style='overflow-y: scroll; overflow-x: hidden; height:400px;'>
								<div id="ShowAjax" style="width: 100%">

								</div>

								<div id="HideAjax" style="width: 100%" >									
									<?php
										$reciver =$this->session->userdata('user_id');
										$sender =$this->uri->segment(4);
										$msg = $this->db->query("SELECT * FROM `chat` WHERE (`sender`, `reciver`) IN (('$sender', '$reciver'),('$reciver','$sender')) ");
										$result = $msg->result();
										foreach($result AS $chat){
											if($chat->sender == $sender){
										?>
									

									<div class="col-md-12 pull-left" style="background: rgb(205, 221, 197); margin-top:20px;  border-radius:5px; padding: 10px; ">
										<div class="col-md-12">
											<img class="img-circle" src="http://localhost/bccp/assets/dash/images/avatars/avatar.png"> <span style="color:#FFF;">
												<?php $query = $this->db->query("SELECT * FROM `admin` WHERE `user_id` = '$sender'");
													echo $query->row(0)->name;
												?>
											</span>
										</div>
										<div class="col-md-12" style="padding: 10px">
											<p style="color:#FFF;"><?php echo $chat->massage;?></p>
											<p><?php echo $chat->time?></p>
										</div>
									</div>	

										<?php }else{?>
									<div class="col-md-12 " style="background: #89c493; margin-top:20px;  border-radius:5px; padding: 10px; ">
										<div class="col-md-12  pull-right text-right">
											<span style="color:#FFF;"><?php $query = $this->db->query("SELECT * FROM `admin` WHERE `user_id` = '$reciver'");
													echo $query->row(0)->name;
												?></span>
											<img class="img-circle" src="<?php echo base_url()?>assets/dash/images/avatars/user.jpg"> 
										</div>
										
										<div class="col-md-12 text-right" style="padding: 10px">
											<p style="color:#FFF;"><?php echo $chat->massage;?></p><br>
											<p><?php echo $chat->time?></p>
										</div>
									</div>

									<?php } }?>
								
						</div>
							<div class="col-md-12">
								<div class="col-md-12" style="margin-top:20px;">
										
										<div class="form-group">
											<input type="hidden" name="sender" id="sender" value="<?php echo $this->session->userdata('user_id')?>">
											<input type="hidden" name="reciver" id="reciver" value="<?php echo $this->uri->segment(4)?>">

											<input  type="text" style="height:100px;" class="form-control" placeholder="type your message..." id="msg" type="text">
										</div>
											<button type="reset" class="btn btn-success" onclick="SendMessage(sender.value,reciver.value,msg.value)"> <i class="fa fa-paper-plane"></i></button>
								</div>	
						</div>
						
						</div>
						
						<!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>

<script type="text/javascript">
  function	SendMessage(sender,reciver,msg){
		
  			var xhttp;    
			  if (sender == "" && reciver == "" && msg == "") {
			    document.getElementById("ShowAjax").innerHTML = "";
			    return;
			  }
			  xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
			    if (this.readyState == 4 && this.status == 200) {
			  	  document.getElementById("HideAjax").innerHTML = "";			      
			      document.getElementById("ShowAjax").innerHTML = this.responseText;
			      document.getElementById("msg").value="";
			    }
			  };
			  xhttp.open("GET", "<?php echo base_url()?>send-maggage?sender="+sender+"&reciver="+reciver+"&msg="+msg, true);
			  xhttp.send();

	}	
</script>

	<script type="text/javascript">		
		var objDiv = document.getElementById("msgg");
		objDiv.scrollTop = objDiv.scrollHeight;
	</script>
	