	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Other Pages</a>
							</li>
							<li class="active">Blank Page</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<?php
									if(isset($_POST['submit'])){


										$id = $this->input->post('id');
										$sugg = $this->input->post('sug');

										if($this->session->userdata('level')==2 && $this->session->userdata('prse')==1){
											$ac = 5;
											$sby = 2;

											$query = $this->db->query("SELECT * FROM `forms` WHERE `f_id` = '$id'");
									        $subject = "Form Disallowed With Suggastions By Prasidant";
									        $message = "Your form has been Disallowed With some Suggastions by Prasidant, disallowed form id =".$query->row(0)->form_id;
									        $uid = $query->row(0)->user_id;
									        $noti = array(
									            'user_id' => $uid,
									            'subject' => $subject,
									            'massage' => $message,
									            'status'  => 1 
									        );
									        $this->db->insert('user_notification',$noti);

										}elseif($this->session->userdata('level')==1){
											$ac = 6;
											$sby =1;

											$query = $this->db->query("SELECT * FROM `forms` WHERE `f_id` = '$id'");
									        $subject = "Form Disallowed With Suggastions By Super Admin";
									        $message = "Your form has been Disallowed With some Suggastions by Super Admin, disallowed form id =".$query->row(0)->form_id;
									        $uid = $query->row(0)->user_id;
									        $noti = array(
									            'user_id' => $uid,
									            'subject' => $subject,
									            'massage' => $message,
									            'status'  => 1 
									        );
									        $this->db->insert('user_notification',$noti);

										}

										 if($this->session->userdata('level')==2 && $this->session->userdata('prse')==0){

										 	$ac = 10;
											$sby = 3;

										 	$query = $this->db->query("SELECT * FROM `forms` WHERE `f_id` = '$id'");
									        $subject = "Form Disallowed With Suggastions By  Admin";
									        $message = "Your form has been Disallowed With some Suggastions by  Admin, disallowed form id =".$query->row(0)->form_id;
									        $uid = $query->row(0)->user_id;
									        $noti = array(
									            'user_id' => $uid,
									            'subject' => $subject,
									            'massage' => $message,
									            'status'  => 1 
									        );
									        $this->db->insert('user_notification',$noti);


								            $query = $this->db->query("SELECT * FROM `app_forms` WHERE `form_id` = '$id' ");
								            if($query->num_rows()==0){

								            //$attr = array('status'=>9, 'p_user' => $this->session->userdata('user_id'));
								            $attr2 = array('user_id' => $this->session->userdata('user_id'), 'form_id' => $id,'status' => 1);
								            $this->db->insert('app_forms',$attr2);
								        }else{
								            //$attr = array('status'=>9, 'p_user' => $this->session->userdata('user_id'));
								            $attr2 = array('user_id' => $this->session->userdata('user_id'), 'form_id' => $id,'status' => 1);
								            $this->db->where('form_id',$id);
								            $this->db->update('app_forms',$attr2);
								        }
								        
								        }

										$attr1 = array('status'=>$ac);
										$this->db->where('f_id',$id);


										if($this->db->update('forms',$attr1)){
											$attr = array(
												'form_id' => $id,
												'date' 	  => date('d-m-Y'),
												'sug_by'  => $sby,
												'sugg'    => $sugg
												
											);
										/*
									        $this->load->library('email');
									        $this->email->from('rahman@eleganttechbd.com', 'Abdur Rahaman');
									        $this->email->to($email);
									        $this->email->cc('salam@eleganttechbd.com');
									        $this->email->bcc('tamal@eleganttechbd.com');               
									        $this->email->subject('Registration Compleate Successfully');
									        $message = "Thank You for Registration. Your User Id = ".$uid." Email is ".$email." Password= ".$pass;
									        $this->email->message($message);									        
									        $this->email->send();

								        */

											if($this->db->insert('sug',$attr)){
												redirect('dashboard/view-materials/'.$id.'/?action=success','refresh');
											}else{
												redirect('dashboard/view-materials/'.$id.'/?action=error','refresh');
											}
										}
									}
								?>
							</div>
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
									<div class="panel panel-default">
										<div class="panel-heading"><div class='panel-title'>Approve With Suggastions</div></div>
											<div class="panel-body">
												<?php echo form_open()?>
													<div class="col-md-6">
														<input type="hidden" name="id" value="<?php echo $this->uri->segment(3)?>">
														<div class="form-group">
															<label>Suggestions</label>
															<textarea name="sug" class="form-control" style="height: 200px;"></textarea>
														</div>
														<input type="hidden" name="id" value="<?php echo $this->uri->segment(3)?>">
														<div class="form-group">
															<input type="submit" name="submit" class="btn btn-success">
														</div>

													</div>
												<?php echo form_close()?>
											</div>										
									</div>	
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>