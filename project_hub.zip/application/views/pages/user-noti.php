	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Dashboard</a>
							</li>
							<li class="active">User Notificatons</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-6">
								<!-- PAGE CONTENT BEGINS -->
									<table class="table">
										<?php 
											$user = $this->session->userdata('user_id');
											$query = $this->db->query("SELECT * FROM `user_notification` WHERE `user_id` = '$user'  ");
											$result = $query->result();
											foreach($result AS $row){
										?>
										<tr>
											<td><a href="<?php echo base_url()?>dashboard/user/notification/view/<?php echo $row->notif_id;?>" class="btn btn-link">
													<div class="alert alert-success">
														<h2><?php echo $row->subject;?></h2>
														<p><?php echo $row->massage?></p>
													</div>
												</a>
											</td>
										</tr>
									<?php }?>
									</table>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>