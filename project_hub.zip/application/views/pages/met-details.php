	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Other Pages</a>
							</li>
							<li class="active">Blank Page</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12">
								<?php
											$fid = $this->uri->segment(3);
											$query = $this->db->query("SELECT * FROM `forms` WHERE `form_id` = '$fid'");
											$result = $query->result();
											foreach($result AS $row){

										?>
								<!-- PAGE CONTENT BEGINS -->
									<div class="col-md-6">
										<div class="well">
											<h4 class="green smaller lighter">What type of product it is ?</h4>
											<?php echo $row->p_type?>
										</div>	

										<div class="well">
											<h4 class="green smaller lighter">Background material ?</h4>
											<?php echo $row->m_back?>
										</div>	

										<div class="well">
											<h4 class="green smaller lighter">Are they relevant of our service ?</h4>
											<?php echo $row->p_rel?>
										</div>	

										<div class="well">
											<h4 class="green smaller lighter">To whom will use this material ?</h4>
											<?php echo $row->wh_use?>
										</div>	

										<div class="well">
											<h4 class="green smaller lighter">How they use this material?</h4>
											<?php echo $row->m_use?>
										</div>										
									</div>

									<div class="col-md-6">
										<div class="well">		
										<?php 
											$query2 = $this->db->query("SELECT * FROM `meeting` WHERE `form_id` = '$row->form_id' ");
											$result2 = $query2->result();
											foreach($result2 AS $row2){
										?>								
											Meeting Date: <?php echo $row2->met_date;?>
											<p><?php echo $row2->comments;?></p>
										<?php }?>
											Meeting Members:<br>
											<?php 

												$query3 = $this->db->query("SELECT * FROM `met_users` INNER JOIN `admin` WHERE `met_users`.`user_id` = `admin`.`user_id` AND `met_users`.`form_id` = '$row->form_id' ");
												$result3 = $query3->result();
												foreach($result3 AS $row3){
											?>
												<a style="margin:3px;" href="#" class="btn btn-xs btn-warning"><i class="fa fa-user"></i> <?php echo $row3->name?></a><br>
											<?php }?>
										</div>	
									</div>
								<?php }?>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
	</div>