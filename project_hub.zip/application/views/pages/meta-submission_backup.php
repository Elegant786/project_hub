	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url()?>dashboard">Home</a>
							</li>

							<li>
								<a href="#">Metarials</a>
							</li>
							<li class="active">Submission</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
				<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<?php
									if(isset($_GET['action']) && $_GET['action']=='success'){
										echo "<div class='alert alert-success'> Form Submitted </div>";
									}

									if(isset($_GET['action']) && $_GET['action']=='failed'){
										echo "<div class='alert alert-danger'> Form not Inserted </div>";
									}
								?>
								
<div class="stepwizard">
    <div class="stepwizard-row setup-panel">
        <div class="stepwizard-step">
            <a href="#step-1" type="button" class="btn btn-primary btn-circle">1</a>
            <p>Step 1</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
            <p>Step 2</p>
        </div>
        <!--<div class="stepwizard-step">
            <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
            <p>Step 3</p>
        </div>-->
    </div>
</div>
<?php  $attr = array('role'=>"form"); echo form_open_multipart('upload-metarials',$attr); ?>
   
    <div class="row setup-content" id="step-1">
    	<div class="col-md-12" style="padding: 20px;">
    		 <h3> Step 1 (User Profile & Metarials Background)</h3>
       	</div>
        <div class="col-xs-4">
            <div class="col-md-12">
               
                <div class="form-group">
                    <label class="control-label">What type of product it is ?</label>
                    <textarea class="form-control" required="required" name="ptype"></textarea>
                </div>
                <div class="form-group">
                    <label class="control-label">Background material ?</label>
                    <textarea class="form-control" required="required" name="m-back"></textarea>
                </div>
               
            </div>
        </div>

        <div class="col-xs-4">
            <div class="col-md-12" >                
                <div class="form-group">
                    <label class="control-label">Are they relevant of our service ?</label>
                    <textarea class="form-control" required="required" name="relserv"></textarea>
                </div>
                <div class="form-group">
                    <label class="control-label">To whom will use this material ?</label>
                    <textarea class="form-control" required="required" name="usermeta"></textarea>
                </div>
               
            </div>
        </div>

        <div class="col-xs-4">
            <div class="col-md-12" >                
                <div class="form-group">
                    <label class="control-label">How they use this material?</label>
                    <textarea class="form-control" required="required" name="howuse"></textarea>
                </div>

                <div class="form-group">
                    <label class="control-label">Category</label>
                    <select name="category" class="form-control">
                    		<option> SELECT CATEGORY</option>
                    	<?php 
							$query = $this->db->get('category');
							$result = $query->result();
							foreach($result AS $row):
								
						?>
						<option value="<?php echo $row->cat_id?>"><?php echo $row->cat_name?></option>
					<?php endforeach;?>
                    </select>
                </div>
                
               
            </div>
        </div>

        <div class="col-xs-12"> <button class="btn btn-primary nextBtn btn-lg pull-right" type="button" >Next</button></div>
    </div> 


    <div class="row setup-content" id="step-2">
    	<h3> Step 3 (Upload Files)</h3>
    	<div class="col-md-6">
    		<div class="input_fields_wrap">
			    <button class="btn btn-success btn-xs add_field_button">Add more</button><br><br>			    
			    <div class="form-group"><input type="file" name="userFiles[]" multiple></div>
			</div><div class="clearfix" style="height:20px;"></div>
			<?php

				$tf = $this->db->get('forms');
				$totf = $tf->num_rows()+1;
				echo form_hidden('fcode', date('ymdhis').$totf);
			?>
			
    	</div>
    	<div class="col-md-12">
    		<div class="here2">

			</div>
    	</div>
    	
        <div class="col-xs-12">
            <div class="col-md-12">                
                <button class="btn btn-success btn-lg pull-right" type="submit">Finish!</button>
            </div>
        </div>
    </div>


<?php echo form_close();?>

								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>