	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Other Pages</a>
							</li>
							<li class="active">Blank Page</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="<ace-settings-btn></ace-settings-btn>">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12">
								<?php
									if(isset($_POST['submit'])){
										$cat = $_POST['cat'];
										$user = $_POST['user'];

										$attr = array(

											'cat_id' => $cat,
											'prse' => 1
										
										);

										$this->db->where('user_id',$user);


								if($this->db->update('admin',$attr)){
									echo "<div class='alert alert-success'> Presidant Added </div>";
								}else{
									echo "<div class='alert alert-success'> Presidant Not Added </div>";
								}
							

									}
								?>
								<!-- PAGE CONTENT BEGINS -->
									<div class="col-md-5">
										<div class="panel panel-default">
											<div class="panel-heading">
												<div class="panel-title">
													Add Pracident Admin
												</div>

											</div>
											<div class="panel-body">
												<?php echo form_open()?>

												<?php
													$cat = $this->uri->segment(4);
													$query = $this->db->query("SELECT * FROM `category` WHERE `cat_id` = '$cat' ");
													$result = $query->result();
													foreach($result AS $row):
												?>
	
													<div class="form-group">
														<label>Category Name</label>
														<input type="hidden" value="<?php echo $row->cat_id?>" name="cat">
														<input type="text" disabled="" class="form-control" value="<?php echo $row->cat_name?>" name="">
													</div>
												<?php endforeach;?>
												<div class="form-group">
													<label>Select User</label>
													<table class="table table-bordered">
														<?php 
															$query = $this->db->select("*")
															 				  ->from('admin')
															 				  ->where('level',2)
															 				  ->get();
															 $result = $query->result();


															 foreach($result AS $row):

														?>
														<tr>

															<td>
																<input value="<?php echo $row->user_id?>" type="radio" name="user"> &nbsp <?php echo $row->name?> <b>(Employee ID: <?php echo $row->uid?>) (Email: <?php echo $row->email;?>)</b>
															</td>

														</tr>
												
													<?php endforeach;?>
													</table>
													</div>
													<div class="form-group">
														<input type="submit" name="submit" class="btn btn-success btn-block" value="Add Precidant">
													</div>
												<?php echo form_close()?>
											</div>

										</div>

									</div>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>