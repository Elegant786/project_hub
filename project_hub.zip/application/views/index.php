<!DOCTYPE html>
<html lang="en">
<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title><?php if(isset($title)){ echo $title; }else{ echo "Dashboard"; }?></title>

		<meta name="description" content="" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="<?php echo base_url()?>assets/dash/css/bootstrap.min.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/dash/font-awesome/4.5.0/css/font-awesome.min.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/dash/wi.css">
		<!-- page specific plugin styles -->

		<!-- text fonts -->
		<link rel="stylesheet" href="<?php echo base_url()?>assets/dash/css/fonts.googleapis.com.css" />

		<!-- ace styles -->
		<link rel="stylesheet" href="<?php echo base_url()?>assets/dash/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
		
		<!--[if lte IE 9]>
			<link rel="stylesheet" href="<?php echo base_url()?>assets/dash/css/ace-part2.min.css" class="ace-main-stylesheet" />
		<![endif]-->
		<link rel="stylesheet" href="<?php echo base_url()?>assets/dash/css/ace-skins.min.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/dash/css/ace-rtl.min.css" />
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
		
		<!--[if lte IE 9]>
		  <link rel="stylesheet" href="<?php echo base_url()?>assets/dash/css/ace-ie.min.css" />
		<![endif]-->
		

		<!-- ace settings handler -->
		<script src="<?php echo base_url()?>assets/dash/js/ace-extra.min.js"></script>

		<!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

		<!--[if lte IE 8]>
		<script src="<?php echo base_url()?>assets/dash/js/html5shiv.min.js"></script>
		<script src="<?php echo base_url()?>assets/dash/js/respond.min.js"></script>
		<![endif]-->
	</head>

	<body class="no-skin" >
		<div id="navbar" class="navbar navbar-default          ace-save-state">
			<div class="navbar-container ace-save-state" id="navbar-container">
				<button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
					<span class="sr-only">Toggle sidebar</span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>
				</button>

				<div class="navbar-header pull-left">
					<a href="<?php echo base_url()?>dashboard" class="navbar-brand">
						<small>
							<i class="fa fa-leaf"></i>
							Elegan Tech Limited
						</small>
					</a>
				</div>

				<div class="navbar-buttons navbar-header pull-right" role="navigation">
					<ul class="nav ace-nav">

			<?php if($this->session->userdata('level')==3){?>
						<li class="purple dropdown-modal">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-bell icon-animated-bell"></i>
								<?php
									$date = date('d-m-Y');

								  	$uid = $this->session->userdata('user_id');
									$query = $this->db->query(" SELECT * FROM `user_notification` WHERE `status` = 1 AND `user_id` = '$uid' ");
									if($query->num_rows()>0){
								?>
								<span class="badge badge-important"><?php echo $query->num_rows();?> </span>									
								<?php }else{?>
									<span class="badge badge-important">0</span>
								<?php }?>

								
							</a>

							<ul class="dropdown-menu-right dropdown-navbar navbar-pink dropdown-menu dropdown-caret dropdown-close">
								
								<?php
									$date = date('d-m-Y');
								  	$uid = $this->session->userdata('user_id');
									$query = $this->db->query("SELECT * FROM `user_notification` WHERE `status` = 1 AND `user_id` = '$uid' ");
									if($query->num_rows()>0){
								?>

								<li class="dropdown-header">
									<i class="ace-icon fa fa-exclamation-triangle"></i>
									<?php echo $query->num_rows()?> Today
								</li>
									<?php }else{?>
									<li class="dropdown-header">
								<i class="ace-icon fa fa-exclamation-triangle"></i>
									0
								</li>
								<?php }?>
								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar navbar-pink">
										
									<?php 
										$uid = $this->session->userdata('user_id');
										$query = $this->db->query("SELECT * FROM `user_notification` WHERE `user_id` = '$uid'  ORDER BY `notif_id` DESC LIMIT  5");
										$result = $query->result();
										foreach($result AS $row){
									?>
										<?php
											if($row->status == 1){
										?>
										<li style=" background-color: #fbe0fc; ">
											<a  href="<?php echo base_url()?>dashboard/user/notification/view/<?php echo $row->notif_id;?>">
												<div class="clearfix">
													<span class="pull-left">
														<i class="btn btn-xs no-hover btn-pink fa fa-comment"></i>
														<?php echo $row->subject;?>
													</span>
													
												</div>
											</a>
										</li>
									<?php } else{?>
										<li>
											<a href="<?php echo base_url()?>dashboard/user/notification/view/<?php echo $row->notif_id;?>">
												<div class="clearfix">
													<span class="pull-left">
														<i class="btn btn-xs no-hover btn-pink fa fa-comment"></i>
														<?php echo $row->subject;?>
													</span>
													
												</div>
											</a>
										</li>


									 <?php } }?>

									</ul>
						     	</li>

						     <li class="dropdown-footer">
									<a href="<?php echo base_url()?>dashboard/user-notifications">
										See all notifications
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
							</li>
						 </ul>
					</li>
<?php }?>
					
					<?php if($this->session->userdata('level')==2 && $this->session->userdata('prse')==0){?>
						<li class="purple dropdown-modal">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-bell icon-animated-bell"></i>
								<?php
									$date = date('d-m-Y');

								  	$uid = $this->session->userdata('user_id');
									$query = $this->db->query("SELECT * FROM `admin_notice` WHERE `status` = 1 AND `user_id` = '$uid' ");
									if($query->num_rows()>0){
								?>
								<span class="badge badge-important"><?php echo $query->num_rows();?></span>									
								<?php }else{?>
									<span class="badge badge-important">0</span>
								<?php }?>

								
							</a>

							<ul class="dropdown-menu-right dropdown-navbar navbar-pink dropdown-menu dropdown-caret dropdown-close">
								
								<?php
									$date = date('d-m-Y');
								  	$uid = $this->session->userdata('user_id');
									$query = $this->db->query("SELECT * FROM `admin_notice` WHERE `status` = 1 AND `user_id` = '$uid' ");
									if($query->num_rows()>0){
								?>

								<li class="dropdown-header">
									<i class="ace-icon fa fa-exclamation-triangle"></i>
									<?php echo $query->num_rows()?> Unread
								</li>
									<?php }else{?>
									<li class="dropdown-header">
								<i class="ace-icon fa fa-exclamation-triangle"></i>
									0
								</li>
								<?php }?>
								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar navbar-pink">
										
									<?php 
										$uid = $this->session->userdata('user_id');
										$query = $this->db->query("SELECT * FROM `admin_notice` INNER JOIN `notification` WHERE  `user_id` = '$uid' AND `notification`.`notif_id` = `admin_notice`.`notice_id` ORDER BY `notification`.`notif_id` DESC ");
										$result = $query->result();
										foreach($result AS $row){
											if($row->status == 1){
									?>

										<li >
											<a href="<?php echo base_url()?>dashboard/notification/view/<?php echo $row->notif_id;?>">
												<div class="clearfix">
													<span class="pull-left">
														<i class="btn btn-xs no-hover btn-pink fa fa-comment"></i>
														<?php echo $row->title;?>
													</span>
													<span class="pull-right badge badge-info"><?php echo $row->date_ad?></span>
												</div>
											</a>
										</li>
										
									<?php }else{ ?>
										<li  ">
											<a href="<?php echo base_url()?>dashboard/notification/view/<?php echo $row->notif_id;?>">
												<div class="clearfix">
													<span class="pull-left">
														<i class="btn btn-xs no-hover btn-pink fa fa-comment"></i>
														<?php echo $row->title;?>
													</span>
													<span class="pull-right badge badge-info"><?php echo $row->date_ad?></span>
												</div>
											</a>
										</li>

									 <?php } }?>

									</ul>
						     	</li>

						     <li class="dropdown-footer">
									<a href="<?php echo base_url()?>dashboard/view-admin-notifications">
										See all notifications
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
							</li>
						 </ul>
					</li>
<?php }?>
<!-- Notification For Precidant Start -->

					<?php if($this->session->userdata('level')==2 && $this->session->userdata('prse')==1){?>				
						<li class="purple dropdown-modal">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-bell icon-animated-bell"></i>
								<?php
									$date = date('d-m-Y');
									$query = $this->db->query("SELECT * FROM `notification` WHERE `status` = 1");
									if($query->num_rows()>0){
								?>
								<span class="badge badge-important"><?php echo $query->num_rows();?></span>									
								<?php }else{?>
									<span class="badge badge-important">0</span>
								<?php }?>

								
							</a>

							<ul class="dropdown-menu-right dropdown-navbar navbar-pink dropdown-menu dropdown-caret dropdown-close">
								
								<?php
									$date = date('d-m-Y');
									$query = $this->db->query("SELECT * FROM `notification` WHERE `status` = 1");
									if($query->num_rows()>0){
								?>

								<li class="dropdown-header">
									<i class="ace-icon fa fa-exclamation-triangle"></i>
									<?php echo $query->num_rows()?> Unread
								</li>
									<?php }else{?>
									<li class="dropdown-header">
								<i class="ace-icon fa fa-exclamation-triangle"></i>
									0
								</li>
								<?php }?>
								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar navbar-pink">
										
									<?php 
										$query = $this->db->query("SELECT * FROM `notification` ORDER BY `notif_id` DESC LIMIT 5");
										$result = $query->result();
										foreach($result AS $row){
											if($row->status == 1){
									?>

										<li style="background-color:rgb(169, 172, 188) ">
											<a href="<?php echo base_url()?>dashboard/notification/view/<?php echo $row->notif_id;?>">
												<div class="clearfix">
													<span class="pull-left">
														<i class="btn btn-xs no-hover btn-pink fa fa-comment"></i>
														<?php echo $row->title;?>
													</span>
													<span class="pull-right badge badge-info"><?php echo $row->date?></span>
												</div>
											</a>
										</li>
									<?php }else{?> 
										<li>
											<a href="<?php echo base_url()?>dashboard/notification/view/<?php echo $row->notif_id;?>">
												<div class="clearfix">
													<span class="pull-left">
														<i class="btn btn-xs no-hover btn-pink fa fa-comment"></i>
														<?php echo $row->title;?>
													</span>
													<span class="pull-right badge badge-info"><?php echo $row->date?></span>
												</div>
											</a>
										</li>


									<?php } }?>

									</ul>
						     	</li>

						     <li class="dropdown-footer">
									<a href="<?php echo base_url()?>dashboard/all-notifications">
										See all notifications
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
							</li>
						 </ul>
					</li>
<?php }?>
	<!-- Notification for Precidant Admin -->
				<?php  if($this->session->userdata('level') !=3  ){?>
						<li class="green dropdown-modal">
						  <?php 
						  	$id = $this->session->userdata('user_id');
						  	$unread = $this->db->query(" SELECT * FROM `chat` WHERE  `reciver` = '$id' AND `status` = 1  ");
						  	if($unread->num_rows()>=0){
						  ?>
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-envelope icon-animated-vertical"></i>
								<span class="badge badge-success"><?php echo $unread->num_rows()?></span>
							</a>
						<?php }else{?>
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-envelope icon-animated-vertical"></i>
								<span class="badge badge-success">0</span>
							</a>
						<?php }?>
							<ul class="dropdown-menu-right dropdown-navbar dropdown-menu dropdown-caret dropdown-close">

								
								
								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar">	

									<?php
										$id = $this->session->userdata('user_id');
										$user = $this->db->query("SELECT * FROM `admin` WHERE `level` = 2 OR `level` = 1 AND `user_id` != '$id'");
										$user = $user->result();
										foreach($user AS $row){
											$msg = $this->db->query("SELECT * FROM `chat` WHERE (`sender`, `reciver`) IN (('$row->user_id', '$id'), ('$id','$row->user_id')) ORDER BY `chat_id` DESC LIMIT 1");

										//$msg = $this->db->query("SELECT * FROM `chat` WHERE (`sender`, `reciver`) IN (('$row->user_id', '$id'), ('$id','$row->user_id')) ORDER BY `chat_id` DESC LIMIT 1");
											
											$result = $msg->result();

										

											foreach($result AS $chat){

												if($chat->status == 2){

									?>								
								
										<li>
											<a href="<?php echo base_url()?>dashboard/chat/user/<?php echo $row->user_id?>" class="clearfix">
												<img src="<?php echo base_url()?>assets/dash/images/avatars/avatar.png" class="msg-photo" alt="Alex's Avatar" />
												<span class="msg-body">
													<span class="msg-title">
														<span class="blue"><?php echo $row->name?>:</span>
														<?php echo  mb_substr($chat->massage, 0, 20)?>.....
													</span>

													<span class="msg-time">
														<i class="ace-icon fa fa-clock-o"></i>
														<span>
															<?php echo $chat->time; ?>

														</span>
													</span>
												</span>
											</a>
										</li>
									<?php }else{ ?>
										<li style="background-color: rgb(201, 252, 210)">
											<a href="<?php echo base_url()?>dashboard/chat/user/<?php echo $row->user_id?>" class="clearfix">
												<img src="<?php echo base_url()?>assets/dash/images/avatars/avatar.png" class="msg-photo" alt="Alex's Avatar" />
												<span class="msg-body">
													<span class="msg-title">
														<span class="blue"><?php echo $row->name?>:</span>
														<?php echo  mb_substr($chat->massage, 0, 20)?>..... 
													</span>

													<span class="msg-time">
														<i class="ace-icon fa fa-clock-o"></i>
														<span>
															<?php 
																	
																echo $this->DashboardModel->timeago(date($chat->time));

																/* $datetime1 = new DateTime(); // Today's Date/Time 
																$datetime2 = new DateTime($chat->time); 
																$interval = $datetime1->diff($datetime2); 
																echo $interval->format('%H hours %I minutes ago');*/ ?>

														</span>
													</span>
												</span>
											</a>
										</li>

									<?php } } }?>
									</ul>
								</li>

								<li class="dropdown-footer">
									<a href="<?php echo base_url()?>dashboard/all-chats">
										See all messages
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
								</li>
							</ul>
						</li>
<?php }?>
						<li class="light-blue dropdown-modal">
							<a data-toggle="dropdown" href="#" class="dropdown-toggle">
								<img class="nav-user-photo" src="<?php echo base_url()?>assets/dash/images/avatars/user.jpg" alt="Jason's Photo" />
								<span class="user-info">
									<small>Welcome,<?php
										$level = $this->session->userdata('level');
										if($level==1){
											echo "Super Admin";
										}elseif($level==2){
											echo "Admin";
										}else{
											echo "User";
										}

									?></small>
									<?php echo $this->session->userdata('name')?>
								</span>

								<i class="ace-icon fa fa-caret-down"></i>
							</a>

							<ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
								<li>
									<a href="<?php echo base_url()?>dashboard/profile-settings">
										<i class="ace-icon fa fa-cog"></i>
										Settings
									</a>
								</li>

								<li>
									<a href="<?php echo base_url()?>dashboard/profile">
										<i class="ace-icon fa fa-user"></i>
										Profile
									</a>
								</li>
								<li>
									<a href="<?php echo base_url()?>dashboard/edit-profile">
										
										<i class='fa fa-edit'></i> Edit Profile
									</a>
								</li>

								<li class="divider"></li>

								<li>
									<a href="<?php echo base_url()?>logout">
										<i class="ace-icon fa fa-power-off"></i>
										Logout
									</a>
								</li>
							</ul>
						</li>
					</ul>
				</div>
			</div><!-- /.navbar-container -->
		</div>

		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			<div id="sidebar" class="sidebar                  responsive                    ace-save-state">
				<script type="text/javascript">
					try{ace.settings.loadState('sidebar')}catch(e){}
				</script>

				<div class="sidebar-shortcuts" id="sidebar-shortcuts">
					<div class="sidebar-shortcuts-large" id="sidebar-shortcuts-large">
						<button class="btn btn-success">
							<i class="ace-icon fa fa-signal"></i>
						</button>

						<button class="btn btn-info">
							<i class="ace-icon fa fa-pencil"></i>
						</button>

						<button class="btn btn-warning">
							<i class="ace-icon fa fa-users"></i>
						</button>

						<button class="btn btn-danger">
							<i class="ace-icon fa fa-cogs"></i>
						</button>
					</div>

					<div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">
						<span class="btn btn-success"></span>

						<span class="btn btn-info"></span>

						<span class="btn btn-warning"></span>

						<span class="btn btn-danger"></span>
					</div>
				</div><!-- /.sidebar-shortcuts -->

				<ul class="nav nav-list">
					
					<?php
				$level = $this->session->userdata('level');
							if($level==1){
								$this->load->view('super-menu');
							}elseif($level==2){
								$this->load->view('admin-menu');
							}else{
								$this->load->view('user-menu');
							}
					?>

					

					
					

					
				</ul><!-- /.nav-list -->

				<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
					<i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
				</div>
			</div>

			<div class="main-content">
					<?php
							if(isset($page)){
								$this->load->view('pages/'.$page);
							}
						?>
			</div><!-- /.main-content -->

			<div class="footer">


					
				<div class="footer-inner">
					<div class="footer-content">
						<span class="bigger-120">
							<a target="_blank" href="https://eleganttechbd.com"><span class="blue bolder">Elegant Tech</span></a>
							Application &copy; 2013-2014
						</span>

						&nbsp; &nbsp;
						<span class="action-buttons">
							<a href="#">
								<i class="ace-icon fa fa-twitter-square light-blue bigger-150"></i>
							</a>

							<a href="#">
								<i class="ace-icon fa fa-facebook-square text-primary bigger-150"></i>
							</a>

							<a href="#">
								<i class="ace-icon fa fa-rss-square orange bigger-150"></i>
							</a>
						</span>
					</div>
				</div>
			</div>

			<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
				<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
			</a>
		</div><!-- /.main-container -->

		<!-- basic scripts -->

		<!--[if !IE]> -->
		<script src="<?php echo base_url()?>assets/dash/js/jquery-2.1.4.min.js"></script>

		<!-- <![endif]-->

		<!--[if IE]>
<script src="<?php echo base_url()?>assets/dash/js/jquery-1.11.3.min.js"></script>
<![endif]-->
		<script type="text/javascript">
			if('ontouchstart' in document.documentElement) document.write("<script src='<?php echo base_url()?>assets/dash/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
		</script>
		<script src="<?php echo base_url()?>assets/dash/js/bootstrap.min.js"></script>

		<!-- page specific plugin scripts -->
		

		<!-- ace scripts -->
		<script src="<?php echo base_url()?>assets/dash/js/ace-elements.min.js"></script>
		<script src="<?php echo base_url()?>assets/dash/js/ace.min.js"></script>

		<!-- inline scripts related to this page -->
	
	<script type="text/javascript">
	$(document).ready(function () {

    var navListItems = $('div.setup-panel div a'),
            allWells = $('.setup-content'),
            allNextBtn = $('.nextBtn');

    allWells.hide();

    navListItems.click(function (e) {
        e.preventDefault();
        var $target = $($(this).attr('href')),
                $item = $(this);

        if (!$item.hasClass('disabled')) {
            navListItems.removeClass('btn-primary').addClass('btn-default');
            $item.addClass('btn-primary');
            allWells.hide();
            $target.show();
            $target.find('input:eq(0)').focus();
        }
    });

    allNextBtn.click(function(){
        var curStep = $(this).closest(".setup-content"),
            curStepBtn = curStep.attr("id"),
            nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
            curInputs = curStep.find("input[type='text'],input[type='url']"),
            isValid = true;

        $(".form-group").removeClass("has-error");
        for(var i=0; i<curInputs.length; i++){
            if (!curInputs[i].validity.valid){
                isValid = false;
                $(curInputs[i]).closest(".form-group").addClass("has-error");
            }
        }

        if (isValid)
            nextStepWizard.removeAttr('disabled').trigger('click');
    });

    $('div.setup-panel div a.btn-primary').trigger('click');
});

	</script>

	<script type="text/javascript">
				$(document).ready(function() {
		    var max_fields      = 10; //maximum input boxes allowed
		    var wrapper         = $(".here2"); //Fields wrapper
		    var add_button      = $(".add_field_button"); //Add button ID
		    
		    var x = 1; //initlal text box count
		    $(add_button).click(function(e){ //on add input button click
		        e.preventDefault();
		        if(x < max_fields){ //max input box allowed
		            x++; //text box increment
		            $(wrapper).append('<div class="form-group"><input type="file" multiple name="userFiles[]"/><a href="#" class="remove_field"><i class="fa fa-trash"></i></a></div>'); //add input box
		        }
		    });
		    
		    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
		        e.preventDefault(); $(this).parent('div').remove(); x--;
		    })
		});
	</script>

	

</body>

</html>
