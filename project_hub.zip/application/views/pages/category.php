	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url()?>dashboard">Dashboard</a>
							</li>
							<li class="active">Category</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12">
								<div class='col-md-12'>
								<?php
									if(isset($_POST['submit'])){
										$cat = $this->input->post('category');
										$cat = ucfirst($cat);
										if($this->db->insert('category',array('cat_name' => $cat))){
											echo "<div class='alert alert-success'> New Category Inserted</div>";
										}else{
											echo "<div class='alert alert-danger'>Error !</div>";
										}
									}

									if(isset($_POST['update'])){
										$cat = $this->input->post('category');
										$cat = ucfirst($cat);
										$this->db->where('cat_id',$this->input->post('id'));
										if($this->db->update('category',array('cat_name' => $cat))){
											echo "<div class='alert alert-success'>  Category Updated</div>";
										}else{
											echo "<div class='alert alert-danger'>Error !</div>";
										}
									}
								?>
								</div>

								<!-- PAGE CONTENT BEGINS -->
								<?php
									if(empty($this->uri->segment(4))){
								?>
									<div class="col-md-5">
										<div class="panel panel-default">
											<div class="panel-heading"><h3 class="panel-title">Create new Category</h3></div>
											<div class="panel-body">
													<?php echo form_open()?>
														<div class="form-group">
															<label>Cateory Name</label>
															<input type="text" required="requireds" name="category" class="form-control">
														</div>
														<div class="form-group">
															<input name="submit" type="submit" class="btn btn-success btn-block">
														</div>
													<?php echo form_close()?>
											</div>
										</div>
									</div>

									<div class="col-md-5 pull-right">
										<div class="panel panel-default">
											<div class="panel-heading"><h3 class="panel-title">All Categorys</h3></div>
												<div class="panel-body">
														<table class="table table-bordered table-responsive table-hover">
															
															<thead>
																<tr>
																	<th width="10">S/N</th>
																	<th>Category Name</th>
																	<th>Action</th>
																</tr>
															</thead>

															<tbody>

																<?php 
																	$query = $this->db->get('category');
																	$result = $query->result();
																	foreach($result AS $row):
																		@$sl++;
																?>
																<tr>
																	<td><?php echo $sl;?></td>
																	<td><?php echo $row->cat_name;?> (
																		<?php
																			$query2 = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$row->cat_id'");
																			echo $query2->num_rows();
																		?>
																	)</td>
																	<td>
																		
																		<div class="btn-group dropup">
																			<button class="btn btn-xs btn-danger">Action</button>

																			<button data-toggle="dropdown" class="btn btn-xs btn-danger dropdown-toggle" aria-expanded="false">
																				<span class="ace-icon fa fa-caret-down icon-only"></span>
																			</button>

																			<ul class="dropdown-menu dropdown-danger">
																				<li>
																					<a href="<?php echo base_url()?>dashboard/category/edit/<?php echo $row->cat_id;?>"> <i class="fa fa-edit"></i>  Edit</a>
																				</li>

																				<li>
																					<a href="<?php echo base_url()?>dashboard/sub-category/add-new/<?php echo $row->cat_id;?>"> <i class="glyphicon glyphicon-tags"></i> &nbsp sub category</a>
																				</li>

																				<li>
																					<a href="<?php echo base_url()?>dashboard/view-forms/category/<?php echo $row->cat_id;?>"> <i class="fa fa-edit"></i> view Forms</a>
																				</li>

																				<li>
																					<a href="<?php echo base_url()?>dashboard/user/add-presedant/<?php echo $row->cat_id;?>"> <i class="fa fa-user"></i> Presidant Admin</a>
																				</li>

																				

																				<li class="divider"></li>

																				<li>
																					<a onclick='return confirm("are you sure ?")' href="<?php echo base_url()?>dashboard/category/delete/<?php echo $row->cat_id?>"><i class='fa fa-trash'></i> Delete</a>
																				</li>
																			</ul>
																		</div>

																	</td>
																</tr>
															<?php endforeach;?>
															</tbody>
														</table>
												</div>
											</div>
										</div><?php }else{
											$id =$this->uri->segment(4);
											$query = $this->db->query("SELECT * FROM `category` WHERE `cat_id` = '$id' ");
											$result = $query->result();
											foreach($result AS $row):
										?>
										<div class="col-md-5">
											<div class="panel panel-default">
												<div class="panel-heading"><h3 class="panel-title">Create new Category</h3></div>
												<div class="panel-body">
														<?php echo form_open()?>
															<div class="form-group">
																<label>Cateory Name</label>
																<input type="text" required="requireds" value="<?php echo $row->cat_name?>" name="category" class="form-control">
																<input type="hidden" name="id" value='<?php echo $row->cat_id?>'>
															</div>
															<div class="form-group">
																<input name="update" type="submit" class="btn btn-success btn-block">
															</div>
														<?php echo form_close()?>
												</div>
											</div>
										</div>
										<?php endforeach; }?>

									</div>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>