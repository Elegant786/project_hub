	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Profile </a>
							</li>
							<li class="active">Settings</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						<div class="row">
							<div class="col-md-12">
								<?php
									if(isset($error)){
										echo "alert alert-danger";
									}
								?>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12">

								<div class="col-md-12">
									<?php
										if(isset($_POST['change'])){
											$pass = $this->session->userdata('password');
											$opass = md5($_POST['old']);
											if($pass==$opass){
												$npass = md5($_POST['npass']);
												$cpass = md5($_POST['cpass']);
												if($npass == $cpass){
													
													$id = $this->session->userdata('user_id');
													$attr = array('password' => $npass);
													$this->db->where('user_id',$id);											
													if($this->db->update('admin',$attr)){
														$this->session->unset_userdata('password');
														$sess = array('password'=>$npass);
														$this->session->set_userdata($sess);
														echo "<div class='alert alert-success'>Password Changed </div>";
													}else{
														echo "<div class='alert alert-warning'> There is an error please check your Inputed Data </div>";
													}
													
												}else{
													echo "<div class='alert alert-warning'> Password And Confirm Password Not Math </div>";
												}

											}else{
												echo "<div class='alert alert-danger'> Error !! Old Password not Match </div>";
											} 
										}
										if(isset($error)){
											echo "<div class='alert alert-danger'>{$error}</div>";
										}
									?>									
								</div>
								<!-- PAGE CONTENT BEGINS -->
									<div class="col-md-5">
										<div class="panel panel-default">
											<div class="panel-heading"><div class="panel-title">Change Password</div></div>
											<div class="panel-body">

												<?php echo form_open()?>
												<div class="form-group">
													<label>Old Password</label>
													<input type="Password" name="old" minlength="5" required="required" class="form-control">
												</div>

												<div class="form-group">
													<label>Password</label>
													<input type="Password" name="npass" minlength="5" required="required" id="password" class="form-control">
												</div>

												<div class="form-group">
													<label>Confirm Password</label>
													<input type="Password" oninput="MatchPass()" minlength="5" required="required" id="confirm" name="cpass" class="form-control">
													<div id="show"></div>
												</div>
												<div class="form-group">													
													<input type="submit" onclick="return confirm('Are You sure want to change ? your password')" id="submit" name="change" value="Change" class="btn btn-success">
												</div>
												<?php echo form_close()?>
											</div>
										</div>
									</div>
								<?php if($this->session->userdata('level')!=3){?>
									<div class="col-md-5">
										<div class="panel panel-default">
											<div class="panel-heading"><div class="panel-title">Change Password</div></div>
												<div class="panel-body">
													<?php echo form_open_multipart("dashboard/upload-signature")?>
														<div class="form-group">
															<label>Signature(Image File: png,Jpg)</label>
															<input type="file" name="image">
														</div>

														<?php

															 $uid =$this->session->userdata("uid");
															 echo form_hidden('uid', $uid);
															 $query = $this->db->query("SELECT * FROM `signatures` WHERE `user_id` = '$uid' ");
															 $result = $query->result();
															 foreach($result AS $sign){
														?>
														<div class="form-group">
																<img src='<?php echo base_url()?>uploads/sign/<?php echo $sign->sig;?>' class="img-responsive" />
														</div>

														

														<?php }?>
														<div class="form-group">
															<button onclick="return confirm('Are You sure ?')" name="upload" type="submit" class="btn btn-success"> <i class="fa fa-upload"></i> Upload signature </button>
														</div>
													<?php echo form_close()?>
												</div>
											</div>
										</div>
								<?php }?>
									
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>

<script type="text/javascript">
	function MatchPass(){
		var pass = document.getElementById('password').value;
		var con = document.getElementById('confirm').value;
		if(pass == con){
			 document.getElementById("show").innerHTML="<p style='color:GREEN'><i class='glyphicon glyphicon-ok'></i> Password And Confirm Password Match</p>";
			 document.getElementById("submit").disabled="";
		}else{
			document.getElementById("show").innerHTML="<p style='color:RED'><i class='glyphicon glyphicon-remove'></i> Password And Confirm Password Not Match</p>";
			document.getElementById("submit").disabled="disabled";
		}
}
</script>