	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">User</a>
							</li>
							<li class="active">Profiles</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->

									<div class="col-md-6">
										<div class="panel panel-default">
											<div class="panel-heading"><div class='panel-title'> <?php echo $this->session->userdata('name')?>' Profile 
											</div></div>
											<div class="panel-body">

												<img style="height: 120; width: 90px; margin: 0px 0px 10px 20px;" src="<?php echo base_url()?>uploads/employee/<?php echo $this->session->userdata('image')?>" class="img-responsive img-thumbnail">

											<div class="profile-user-info profile-user-info-striped">
												
												<div class="profile-info-row">
													<div class="profile-info-name"> User Name </div>

													<div class="profile-info-value">
														<span class="editable editable-click editable-unsaved" id="username" style="display: inline; background-color: rgba(0, 0, 0, 0);"><?php echo $this->session->userdata('name')?></span>
													</div>
												</div>

												<div class="profile-info-row">
													<div class="profile-info-name">Email</div>

													<div class="profile-info-value">
														<span class="editable editable-click editable-unsaved" id="username" style="display: inline; background-color: rgba(0, 0, 0, 0);"><?php echo $this->session->userdata('email')?></span>
													</div>
												</div>

												<div class="profile-info-row">
													<div class="profile-info-name">Level</div>

													<div class="profile-info-value">
														<span class="editable editable-click editable-unsaved" id="username" style="display: inline; background-color: rgba(0, 0, 0, 0);"><?php 


														$level = $this->session->userdata('level');
														if($level==1){
															echo "Super Admin";
														}elseif($level==2 && $this->session->userdata('prse')==1){
															echo "Admin (Presedant)";
														}elseif($level==2 && $this->session->userdata('prse')==0){
															echo "Admin";
														}elseif($level==3){
															echo "Normal user";
														}
														?></span>
													</div>
												</div>

												

												<div class="profile-info-row">
													<div class="profile-info-name"> Category </div>
													<div class="profile-info-value">
														<span class="editable editable-click editable-unsaved" id="username" style="display: inline; background-color: rgba(0, 0, 0, 0);">
															<?php
																$query = $this->db->select("*")
																				  ->from("category")
																				  ->where('cat_id',$this->session->userdata('cat'))
																				  ->get();
																if($query->num_rows()==1){
																	echo $query->row(0)->cat_name;
																}
															?>

														</span>

													</div>
												</div>

												<?php 
													if($this->session->userdata('level')==2 && $this->session->userdata('prse')==0){
												?>

													<div class="profile-info-row">
														<div class="profile-info-name"> Category </div>
														<div class="profile-info-value">
															<span class="editable editable-click editable-unsaved" id="username" style="display: inline; background-color: rgba(0, 0, 0, 0);">
																<?php
																	$query = $this->db->select("*")
																					  ->from("sub_cat")
																					  ->where('sub_id',$this->session->userdata('sub'))
																					  ->get();
																	if($query->num_rows()==1){
																		echo $query->row(0)->sub_name;
																	}
																?>

															</span>

														</div>
													</div>
												<?php }?>
												
												<?php
													if($this->session->userdata('level') < 3 ){
												?>

												<div class="profile-info-row">
													<div class="profile-info-name"> Signature</div>

													<div class="profile-info-value">
														<?php
														 $uid =$this->session->userdata("uid");
														 $query = $this->db->query("SELECT * FROM `signatures` WHERE `user_id` = '$uid' ");
															 $result = $query->result();
															 foreach($result AS $sign){
														?>
													  <span class="editable editable-click editable-unsaved" id="about" style="display: inline; background-color: rgba(0, 0, 0, 0);">
													  	<img src="<?php echo base_url()?>uploads/sign/<?php echo $sign->sig;?>" class="img-responsive" />
														 &nbsp;
													 </span>
													 <?php } ?>
													</div>
												</div>
												<?php }?>
											</div>
										  </div>
										
										</div>
									</div>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>