	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="<?php echo base_url()?>dashboard">Home</a>
							</li>

							<li>
								<a href="#">Metarials</a>
							</li>
							<li class="active">Submission</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
			             	<div class="col-xs-12">
					           <?php $attr = array('role'=>"form"); echo form_open_multipart('upload-metarials',$attr); ?>
                                    <?php if($this->uri->segment(3)==NULL){?>
                                        <div class="panel panel-default">
                                            <div class="panel-heading"><h4 class="panel-title">New Submission</h4></div>
                                                <div class="panel-body">                                                
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Select Category</label>
                                                        <select class="form-control" onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                                                            <option value="<?php echo base_url()?>dashboard/metarial-submission/">Select...</option>
                                                            <?php
                                                                $query = $this->db->get('category');
                                                                $result = $query->result();
                                                                foreach($result AS $row):
                                                            ?>

                                                            <option value="<?php echo base_url()?>dashboard/metarial-submission/<?php echo $row->cat_id?>"><?php echo $row->cat_name;?></option>
                                                            
                                                            <?php endforeach;?>

                                                        </select>
                                                    </div>
                                                </div> 
                                            </div>                                           
                                        </div>
                                    <?php }?>
                                    <?php if($this->uri->segment(3)){?>
                                        <div class="panel panel-default">
                                          <div class="panel-heading"><h4 class="panel-title">New Submission</h4></div>
                                              <div class="panel-body">                                                
                                                  <div class="col-md-6">
                                                        <?php echo form_hidden('category',$this->uri->segment(3));?>
                                                        
                                                       

                                                        <div class="form-group">
                                                            <label for="name">Name</label>
                                                            <input type="text" name="ptype" class="form-control">
                                                        </div>

                                                         <div class="form-group">
                                                            <label for="">Description</label>
                                                            <textarea name="m-back" id="" cols="30" rows="10" class="form-control"></textarea>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">Comment</label>
                                                           <textarea name="relserv" id="" cols="30" rows="10" class="form-control"></textarea>
                                                        </div> 
                                                    
                                                    <button type="button" onclick="myFunction()">Advanced form</button>
                                                        <br>
                                                        <br>
                                                        <br>
                                                        <div id="hide" style="display: none;">

                                                             <div class="form-group">
                                                                <label for="">file Included</label>
                                                               <textarea name="howuse" id="" cols="30" rows="10" class="form-control"></textarea>
                                                            </div> 

                                                             <div class="form-group">
                                                                <label for="">Tags</label>
                                                                <input type="text" name="usermeta" class="form-control">
                                                            </div>


                                                        </div>

                                                </div>

                                                    <div class="col-md-6">
                                                         <div class="form-group">
                                                            <label>Sub Category</label>
                                                            <select class="form-control" name="sub_cat">
                                                                <option>Select one</option>
                                                                <?php
                                                                    $cat = $this->uri->segment(3);
                                                                    $query = $this->db->query("SELECT * FROM  `sub_cat` WHERE `cat_id` = '$cat' ");
                                                                    $result = $query->result();
                                                                    foreach($result AS $row){
                                                                ?>
                                                                <option value="<?php echo $row->sub_id?>"> <?php echo $row->sub_name;?></option>
                                                                            
                                                                <?php }?>

                                                            </select>
                                                        </div>

                                                        <div class="">
                                                        <h3>Upload File <small>(Max File Size 25 MB)</small></h3><br>
                                                        
                                                        <div class="col-md-6">
                                                            <div class="input_fields_wrap">
                                                                <button class="btn btn-success btn-xs add_field_button">Add more</button><br><br>               
                                                                <div class="form-group"><input required="required" type="file" name="userFiles[]" multiple></div>
                                                            </div><div class="clearfix" style="height:20px;"></div>
                                                            <?php

                                                                $tf = $this->db->get('forms');
                                                                $totf = $tf->num_rows()+1;
                                                                echo form_hidden('fcode', date('ymdhis').$totf);
                                                            ?>
                                                            
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="here2">

                                                            </div>
                                                        </div>
                                                        
                                                       
                                                    </div>
                                                    </div>

                                                <div class="col-md-12">
                                                    <button class="btn btn-success" type="submit" name="submit"> Submit Form</button>
                                                </div>
                                            </div>
                                        </div>

                                    <?php }?>

                               <?php echo form_close()?>
                                
    						</div><!-- /.col -->
    					</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>
<script>
function myFunction() {
    var x = document.getElementById("hide");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
</script>