	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Notification </a>
							</li>
							<li class="active">View</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-5">
								<!-- PAGE CONTENT BEGINS -->
									<div class="panel panel-default">
										<div class="panel-heading"><div class="panel-title"> Notification </div></div>	
										<div class="panel-body">
											<?php
												$id = $this->uri->segment(5);
												$query = $this->db->query("SELECT * FROM `user_notification` WHERE `notif_id` = $id ");
												$this->db->where('notif_id',$id);
												$this->db->update('user_notification',array('status' => 2));
												$result = $query->result();
												foreach($result AS $row):
											?>
											<h3><?php echo $row->subject?></h3>
											<h6><i class='fa fa-calendar'></i> &nbsp Date: <?php echo $row->date;?></h6>
											<p>
												<?php echo $row->massage;?>
											</p>

										<?php endforeach;?>
										</div>
									</div>
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
							<div class="col-md-5">
								
								</div>
							

							</div>
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>