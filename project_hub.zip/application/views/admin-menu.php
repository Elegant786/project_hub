<li class="">
						<a href="<?php echo base_url()?>dashboard">
							<i class="menu-icon fa fa-tachometer"></i>
							<span class="menu-text"> Dashboard </span>
						</a>

						<b class="arrow"></b>
					</li>

					<!--<li class="">
						<a href="<?php echo base_url()?>dashboard/new-category">
							<i class="menu-icon fa fa-tags"></i>
							<span class="menu-text"> Category </span>
						</a>
						<b class="arrow"></b>
					</li>-->				

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-desktop"></i>
							<span class="menu-text"> Metarials
								
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							
							<?php 
								if($this->session->userdata('level')==2 && $this->session->userdata('prse')==0){
							?>							
								<li class="">
									<a href="<?php echo base_url()?>dashboard/user-submited-metarials" class="">
										<i class="menu-icon fa fa-caret-right"></i>
										New Submited 
										<b class="arrow fa fa-angle-down"></b>
									</a>
								</li>

								<li class="">
									<a href="<?php echo base_url()?>dashboard/presedant-review-forms" class="">
										<i class="menu-icon fa fa-caret-right"></i>
										Presedant Review 
										<b class="arrow fa fa-angle-down"></b>
									</a>
								</li>

								<li class="">
									<a href="<?php echo base_url()?>dashboard/admin-suggastions-forms" class="">
										<i class="menu-icon fa fa-caret-right"></i>
											Disallow With Suggastion 
										<b class="arrow fa fa-angle-down"></b>
									</a>
								</li>

								<li class="">
									<a href="<?php echo base_url()?>dashboard/user-disallowed-metarials" class="">
										<i class="menu-icon fa fa-caret-right"></i>
										Disallowed Metarials 
										<b class="arrow fa fa-angle-down"></b>
									</a>
								</li>

								<li class="">
									<a href="<?php echo base_url()?>dashboard/admin-all-metarials" class="">
										<i class="menu-icon fa fa-caret-right"></i>
										view All
										<b class="arrow fa fa-angle-down"></b>
									</a>
								</li>
							<?php }elseif($this->session->userdata('level')==2 && $this->session->userdata('prse')==1){?>
								<li class="">
									<a href="<?php echo base_url()?>dashboard/presedant-review-forms" class="">
										<i class="menu-icon fa fa-caret-right"></i>
										Super Review 
										<b class="arrow fa fa-angle-down"></b>
									</a>
								</li>
								
								<li class="">
									<a href="<?php echo base_url()?>dashboard/admin-all-metarials" class="">
										<i class="menu-icon fa fa-caret-right"></i>
										view All
										<b class="arrow fa fa-angle-down"></b>
									</a>
								</li>
							<?php }?>

						</ul>
					</li>
<!-- 
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-user"></i>
							<span class="menu-text"> User management
								
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="<?php echo base_url()?>dashboard/new-user" class="">
									<i class="menu-icon fa fa-caret-right"></i>
										<i class='fa fa-plus'></i> Add user
									<b class="arrow fa fa-angle-down"></b>
								</a>
							</li>
							<li class="">
								<a href="<?php echo base_url()?>dashboard/all-users" class="">
									<i class="menu-icon fa fa-caret-right"></i>
									All Users 
									<b class="arrow fa fa-angle-down"></b>
								</a>
							</li>
						</ul>
					
					</li>
-->
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-cogs"></i>
							<span class="menu-text">Settings
								
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu">
							<li class="">
								<a href="<?php echo base_url()?>dashboard/e-mail-settings" class="">
									<i class="menu-icon fa fa-caret-right"></i>
										<i class='fa fa-envelope'></i> Email Settings
									<b class="arrow fa fa-angle-down"></b>
								</a>
							</li>
							<li class="">
								<a href="<?php echo base_url()?>dashboard/all-users" class="">
									<i class="menu-icon fa fa-caret-right"></i>
									All Users
									<b class="arrow fa fa-angle-down"></b>
								</a>
							</li>
						</ul>					
					</li>

					<!-- <li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-desktop"></i>
							<span class="menu-text">
								
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="#" class="dropdown-toggle">
									<i class="menu-icon fa fa-caret-right"></i>
									Layouts
									<b class="arrow fa fa-angle-down"></b>
								</a>
							</li>
						</ul>
					</li>-->