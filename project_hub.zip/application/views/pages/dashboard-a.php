	<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
		


          
          ['Task', 'Final Activity'],
         
       		

       		
		<?php 
			$cat = $this->session->userdata('cat');
			$sub = $this->session->userdata('sub');
			$id = $this->session->userdata('id');

			$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$cat' AND `sub_cat` = '$sub' AND `status` = 9 ");
			if($query->num_rows()>=0){
			
		?>
          ['Approved ',    <?= $query->num_rows()?>],
       
          <?php }?>

          <?php 
										$cat = $this->session->userdata('cat');
										$sub = $this->session->userdata('sub');
										$id = $this->session->userdata('id');

										$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$cat' AND `sub_cat` = '$sub' AND `status` = 11 ");
										if($query->num_rows()>=0){
										
									?>

          ['Dis Allowed',  <?php echo $query->num_rows()?>],
          
          <?php }?>

     		<?php 
				$cat = $this->session->userdata('cat');
				$sub = $this->session->userdata('sub');
				$id = $this->session->userdata('id');

				$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$cat' AND `sub_cat` = '$sub' AND `status` = 10 ");
				if($query->num_rows()>=0){
				
			?>


          ['Suggest',  <?php echo $query->num_rows()?>],
          
      		<?php }?>

        ]);

        var options = {
          title: 'Activity Chart'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>

	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Dashboard</a>
							</li>
							<li class="active">Admin</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->

						
					</div>

					<div class="page-content">
							
						<!-- chart 1 -->
									<div class="col-md-6">	
									<?php 
										$cat = $this->session->userdata('cat');
										$sub = $this->session->userdata('sub');
										$id = $this->session->userdata('id');

										$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$cat' AND `sub_cat` = '$sub' AND `status` = 2 ");
										if($query->num_rows()>=0){
										
									?>									
										<div class="infobox infobox-green">
											<div class="infobox-icon">
												<i class="ace-icon fa fa-comments"></i>
											</div>

											<div class="infobox-data">
												<span class="infobox-data-number"><?php echo $query->num_rows()?></span>
												<div class="infobox-content">In Review</div>
											</div>
											
										</div>
									<?php }?>

									<?php 
										$cat = $this->session->userdata('cat');
										$sub = $this->session->userdata('sub');
										$id = $this->session->userdata('id');

										$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$cat' AND `sub_cat` = '$sub' AND `status` = 9 ");
										if($query->num_rows()>=0){
										
									?>
										
										<div class="infobox infobox-blue">
											<div class="infobox-icon">
												<i class="ace-icon fa fa-twitter"></i>
											</div>

											<div class="infobox-data">
												<span class="infobox-data-number"><?php echo $query->num_rows()?></span>
												<div class="infobox-content">Approve</div>
											</div>
										</div>
									<?php }?>

									<?php 
										$cat = $this->session->userdata('cat');
										$sub = $this->session->userdata('sub');
										$id = $this->session->userdata('id');

										$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$cat' AND `sub_cat` = '$sub' AND `status` = 10 ");
										if($query->num_rows()>=0){
										
									?>

										<div class="infobox infobox-blue2">
											<div class="infobox-progress">
												<div class="easy-pie-chart percentage" data-percent="42" data-size="46" style="height: 46px; width: 46px; line-height: 45px;">
													
												<canvas height="46" width="46"></canvas></div>
											</div>

											<div class="infobox-data">
												<span class="infobox-text"><?= $query->num_rows()?></span>

												<div class="infobox-content">												
													Total Suggest
												</div>
											</div>
										</div>
									<?php }?>
										
									<?php 
										$cat = $this->session->userdata('cat');
										$sub = $this->session->userdata('sub');
										$id = $this->session->userdata('id');

										$query = $this->db->query("SELECT * FROM `forms` WHERE `cat_id` = '$cat' AND `sub_cat` = '$sub' AND `status` = 11 ");
										if($query->num_rows()>=0){
										
									?>

										<div class="infobox infobox-blue2">
											<div class="infobox-progress">
												<div class="easy-pie-chart percentage" data-percent="42" data-size="46" style="height: 46px; width: 46px; line-height: 45px;">
													
												<canvas height="46" width="46"></canvas></div>
											</div>

											<div class="infobox-data">
												<span class="infobox-text"><?= $query->num_rows()?></span>

												<div class="infobox-content">												
													Disallowed
												</div>
											</div>
										</div>
									</div>
									<?php }?>
						 <!-- Chart End -->

						 <div class="col-md-5">
									<div id="piechart"></div>
						 </div>
					</div>
				</div>