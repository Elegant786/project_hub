
<?php

$msg = $this->db->query("SELECT * FROM `chat` WHERE (`sender`, `reciver`) IN (('$sender', '$reciver'),('$reciver','$sender')) ");
$result = $msg->result();
foreach($result AS $chat){

?>
<?php if($chat->sender == $sender){?>
<div class="col-md-12 " style="background: #89c493; margin-top:20px;  border-radius:5px; padding: 10px; ">	
	<div class="col-md-4 pull-right">
		<span style="color:#FFF;"><?php $query = $this->db->query("SELECT * FROM `admin` WHERE `user_id` = '$sender'");
													echo $query->row(0)->name;
												?></span>
		<img class="img-circle" src="http://localhost/bccp/assets/dash/images/avatars/avatar.png"> 
	</div>
	<div class="col-md-12" style="padding: 10px">
		<p style="color:#FFF;"><?php echo $chat->massage?></p>

		<h6>

				<i class="ace-icon fa fa-clock-o"></i> 
				<?php 
					echo $chat->time;
				?>
		</h6>

	</div>
</div>
<?php }else{?>

<div class="col-md-12 pull-left" style="background: #89c493; margin-top:20px; border-radius:5px; padding: 10px; ">
	<div class="col-md-4">
		<img class="img-circle" src="http://localhost/bccp/assets/dash/images/avatars/avatar.png"> <span style="color:#FFF;"><?php $query = $this->db->query("SELECT * FROM `admin` WHERE `user_id` = '$reciver'");
													echo $query->row(0)->name;
												?></span>
		<h6>
			<i class="ace-icon fa fa-clock-o"></i> 
				<?php 
					$datetime1 = new DateTime(); // Today's Date/Time 
					$datetime2 = new DateTime($chat->time); 
					$interval = $datetime1->diff($datetime2); 
					echo $chat->time; 

				?>
		</h6>
	</div>
	<div class="col-md-12" style="padding: 10px">
		<p style="color:#FFF;"><?php echo $chat->massage?></p>
	</div>
</div>									



<?php } }?>