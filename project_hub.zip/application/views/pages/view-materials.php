	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Dashboard</a>
							</li>
							<li class="active">View Metarials</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
									<div class="panel panel-default">
										<div class="panel-heading"><div class='panel-title'> Panel Title </div></div>
										<div class="panel-body">
												<?php
													$fid = $this->uri->segment(3);
													$query = $this->db->query("SELECT * FROM `forms` WHERE `f_id` = '$fid' ");
													$result = $query->result();
													foreach($result AS $form):
														$user = $this->db->query("SELECT * FROM `admin` WHERE `user_id` = '".$form->user_id."' ");
														$cat = $this->db->query("SELECT * FROM `category` WHERE `cat_id` = '".$form->cat_id."' ");
														$sub = $this->db->query("SELECT * FROM `sub_cat` WHERE `sub_id` = '".$form->sub_cat."' ");
												?>
												<div class="col-md-6">
													<table class="table">
														<thead>
															<tr>
																<td>Name: <?php echo $user->row(0)->name?></td>
																<td>Email: <?php echo $user->row(0)->email?></td>
															</tr>
															<tr>
																<td>Gender : <?php if($user->row(0)->gender == 1){ echo "Male"; }else{ echo "Female"; }?></td>
																<td>Contact: <?php echo $user->row(0)->organization?></td>
															</tr>
															<tr>
																<td>Category : <?php echo $cat->row(0)->cat_name;?></td>
																<td>Sub Category : <?php echo $sub->row(0)->sub_name;?></td>
															</tr>
														</thead>
													</table>
													<div style="border: 1px solid #F1f1f1; padding: 10px;">
															<div class="form-group">
																<label class="control-label"><b>Title</b></label>
																<p><?php echo $form->p_type?></p>
															</div>

															<div class="form-group">
																<label class="control-label"><b>Description</b></label>
																<p><?php echo $form->p_rel?></p>
															</div>

															<div class="form-group">
																<label class="control-label"><b>Commant</b></label>
																<p><?php echo $form->m_use?></p>
															</div>

															<div class="form-group">
																<label class="control-label"><b>Included Files</b></label>
																<p><?php echo $form->m_back?></p>
															</div>

															<div class="form-group">
																<label class="control-label"><b>Tags</b></label>
																<p><?php echo $form->wh_use?></p>
															</div>
													</div>
											</div>	

								<div class="col-md-6">
									<!--<div class="col-md-5 pull-right" >
										<a style="margin-bottom: 10;" class="btn btn-success" href="<?php echo base_url()?>dashboard/arrange-meeting/<?php echo $form->form_id;?>">Arrange Meeting</a>
										<br>
										<br>
									</div>-->
									
									<table class="table table-responsive">
									<tr>
										<td colspan="3"> Uploaded Files</td>
									</tr>
										<?php
												$query4 = $this->db->select("*")
																   ->from("files")
																   ->where('form_code',$form->form_id)
																   ->get();
												$result4 = $query4->result();
												foreach($result4 AS $row4){
													@$sl++;
													$ty = explode('.',$row4->file_name);
													

													$img = array('jpg','jpeg','gif','png');
													$doc = array('doc','docx');
													$video = array('mp4','mpeg4','mov','3gp');
													$audio = array('mp3','amr','ogg');
													$pdf = array('pdf');
													

													if(in_array($ty[1],$img)){
											?>	
										<tr id="">
											<td><?php echo $sl?></td>	
											<td>
												
												<div class="col-md-12">
													<img src="<?php echo base_url()?>uploads/<?php echo $row4->file_name?>" class="img-thumbnail" alt="">
													<a href="<?php echo base_url()?>dashboard/downloadFile/?file=<?php echo $row4->file_name?>" target="_blank" class='btn btn-xs btn-success' style='margin-top: 10px;'><i class='fa fa-download'></i> Download</a>
												</div>

											</td>
											
											
										</tr>
									<?php }elseif(in_array($ty[1],$doc)){?>
										<tr><td><?php echo $sl?></td>
												
											<td>
												<div class="col-md-12">
													<img src="<?php echo base_url()?>assets/word.png" class='img-thumbnail'>
													<p>
														<input type="hidden" id="did<?php echo $sl?>" name="" value="<?php echo $row4->file_name?>">
														<a href="<?php echo base_url()?>dashboard/downloadFile/?file=<?php echo $row4->file_name?>" target="_blank" class='btn btn-xs btn-success' style='margin-top: 10px;'><i class='fa fa-download'></i> Download</a>
													</p>
												</div>
											</td>
											
										</tr>

									<?php }elseif(in_array($ty[1],$video)){?>
										<tr><td><?php echo $sl?></td>												
											<td>
												<div class="col-md-12">
													<video width="400" controls>
													  <source src="<?php echo base_url()?>uploads/<?php echo $row4->file_name?>" type="video/<?php echo $ty[1]?>">													  
													  Your browser does not support HTML5 video.
													</video>
													<a href="<?php echo base_url()?>dashboard/downloadFile/?file=<?php echo $row4->file_name?>" target="_blank" class='btn btn-xs btn-success' style='margin-top: 10px;'><i class='fa fa-download'></i> Download</a>
												</div>
											</td>	
																					
										</tr>
									<?php }elseif(in_array($ty[1],$pdf)){?>
										<tr><td><?php echo $sl?></td>												
											<td>
												<div class="col-md-12">
													<frameset cols="25%,*"> 														
														<frame src="<?php echo base_url()?>uploads/<?php echo $row4->file_name;?>" name="pdf-frame" id="pdf-frame"/> 
													</frameset>
													<a href="<?php echo base_url()?>dashboard/downloadFile/?file=<?php echo $row4->file_name?>" target="_blank" class='btn btn-xs btn-success' style='margin-top: 10px;'><i class='fa fa-download'></i> Download</a>
												</div>
											</td>
																					
										</tr>

									<?php }elseif(in_array($ty[1],$audio)){?>

										<tr><td><?php echo $sl?></td>												
											<td>
												<div class="col-md-12">
													<b>Audio File</b><br>
													<audio controls>
													  <source src="<?php echo base_url()?>uploads/<?php echo $row4->file_name;?>" type="audio/<?php echo $ty[1]?>">													 
													Your browser does not support the audio element.
													</audio>
													<a href="<?php echo base_url()?>dashboard/downloadFile/?file=<?php echo $row4->file_name?>" target="_blank" class='btn btn-xs btn-success' style='margin-top: 10px;'><i class='fa fa-download'></i> Download</a>
												</div>
											</td>
																					
										</tr>

									<?php } }?>
								</table>

							</div>
<?php
$query2 = $this->db->query("SELECT * FROM `sug` WHERE `form_id` = '$form->f_id' ORDER BY `sug_id` DESC"); 
if($query2->num_rows()>0){

?>
							<div class="col-md-12">
									<div class="col-xs-12 col-sm-6 widget-container-col ui-sortable" id="widget-container-col-8">
											<div class="widget-box widget-color-dark ui-sortable-handle" id="widget-box-8">
												<div class="widget-header">
													<h5 class="widget-title bigger lighter">Suggastons</h5>

													

													<div class="widget-toolbar">
														<div class="progress progress-mini progress-striped active pos-rel" style="width:60px;" data-percent="100%">
															<div class="progress-bar progress-bar-danger" style="width:100%"></div>
														</div>
													</div>
												</div>

													<?php
														
														$result2 = $query2->result();
														foreach($result2 AS $row2){
															@$sl1++;
													?>

												<div class="widget-body">
													<div class="widget-toolbox" id="widget-toolbox-1">
													</div>
													
													<div class="widget-main padding-16">
														<?php echo "(".$sl1.") ".$row2->sugg;
															if($row2->sug_by==2){
																echo "<br><br><span class='label label-inverse arrowed'> By -Presedant</span>";
															}elseif($row2->sug_by==1){
																echo "<br><br><span class='label label-success arrowed'> By - Super Admin</span>";
															}else{
																echo "<br><br><span class='label label-success arrowed'> By -  Admin</span>";
															}
														?>
													</div>													
												</div>

												<?php }?>
											</div>
										</div>
		</div>
<?php }?>
		<br><br>

<div class="col-md-12">
			<div class="col-md-4">
				
				<table>
				<!-- Super Admin -->
					<?php if($this->session->userdata('level')==1){?>
						<?php if($form->status ==3 ||$form->status ==11 || $form->status ==8 ){?>
									<tr>
										<td><div class="alert alert-danger"> This Form Is Disallowed </div></td>
									</tr>
						<?php }elseif($form->status ==7){?>
									<tr>
										<td><div class="alert alert-success">This Form is Allowed</div></td>
									</tr>
						<?php }else{?>
					
							<tr>
								<td><a style="margin-right: 2px;" href="<?php echo base_url()?>dashboard/approve-super/<?php echo $form->f_id?>" class='btn btn-success btn-xs'>Approved</a></td>
								<td><a style="margin-right: 2px;" href="<?php echo base_url()?>dashboard/approve-with-suggastions/<?php echo $form->f_id?>"class='btn btn-warning btn-xs'>Approved With Suggastion</a></td>
								<td><a style="margin-right: 2px;" href="<?php echo base_url()?>dashboard/super-form-disallowed/<?php echo $form->f_id?>" class='btn btn-danger btn-xs'>Disallowed</a>
								</td>
							</tr>

						<?php } }

						elseif($this->session->userdata('level')==2 && $this->session->userdata('prse')==1){?>
							<?php if($form->status ==3 ||$form->status ==11 || $form->status ==8 ){?>
									<tr>
										<td><div class="alert alert-danger"> This Form Is Disallowed </div></td>
									</tr>
								<?php }elseif($form->status ==7){?>
									<tr>
										<td><div class="alert alert-success">This Form is Allowed</div></td>
									</tr>
								<?php }elseif($form->status == 5){?>
									<tr>
										<td><div class="alert alert-success">This Form is Allowed</div></td>
									</tr>

								<?php } else{?>
									<tr>
										<td>
											<a style="margin-right: 2px;" href="<?php echo base_url()?>dashboard/approve/<?php echo $form->f_id?>" class='btn btn-success btn-xs'>Approved</a>
											</td>

											<td>
											<a style="margin-right: 2px;" href="<?php echo base_url()?>dashboard/approve-with-suggastions/<?php echo $form->f_id?>"class='btn btn-warning btn-xs'>Approved With Suggastion</a>

											</td>

											<td>
											<a style="margin-right: 2px;" href="<?php echo base_url()?>dashboard/form-disallowed/<?php echo $form->f_id?>" class='btn btn-danger btn-xs'>Disallowed</a>
											</td>
									</tr>
								
						<?php } }

						elseif($this->session->userdata('level')==2 && $this->session->userdata('prse')==0){?>
								<?php if($form->status ==3 ||$form->status ==11 || $form->status ==8 ){?>
									<tr>
										<td><div class="alert alert-danger"> This Form Is Disallowed </div></td>
									</tr>
								<?php }elseif($form->status == 9){?>
									<tr>
										<td><div class="alert alert-success"> This Form Is Allowed </div></td>
									</tr>
								<?php }elseif($form->status == 10 ){?>
									<tr>
										<td><div class="alert alert-success"> Disallowed With Suggastion</div></td>
									</tr>

								<?php }else{?>
							<tr>
										<td>
											<a style="margin-right: 2px;" href="<?php echo base_url()?>dashboard/approve/<?php echo $form->f_id?>" class='btn btn-success btn-xs'>Approved</a>
											</td>

											<td>
											<a style="margin-right: 2px;" href="<?php echo base_url()?>dashboard/approve-with-suggastions/<?php echo $form->f_id?>"class='btn btn-warning btn-xs'>Approved With Suggastion</a>

											</td>

											<td>
											<a style="margin-right: 2px;" href="<?php echo base_url()?>dashboard/form-disallowed/<?php echo $form->f_id?>" class='btn btn-danger btn-xs'>Disallowed</a>
											</td>
									</tr>
								
						<?php } }?>
				<!-- Super Admin -->

				</table>
			</div>
</div>

				<?php endforeach;?>
			</div>
		</div>
	<!-- PAGE CONTENT ENDS -->
</div><!-- /.col -->
</div><!-- /.row -->



</div><!-- /.page-content -->
</div>