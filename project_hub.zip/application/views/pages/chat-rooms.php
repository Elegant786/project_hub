	<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>

							<li>
								<a href="#">Messages</a>
							</li>
							<li class="active">Chat Rooms</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>
						</div>
						
						<div class="row">
							<div class="col-xs-12" style="overflow-y: scroll; overflow-x: hidden; width: 50%; height: 700px;">
								
								<table class="table table-bordered table-hover">
									
									<tbody>

									<?php
										$id = $this->session->userdata('user_id');
										$user = $this->db->query("SELECT * FROM `admin` WHERE `level` = 2 OR `level` = 1 AND `user_id` != '$id'");
										$user = $user->result();
										foreach($user AS $row){
											$msg = $this->db->query("SELECT * FROM `chat` WHERE (`sender`, `reciver`) IN (('$row->user_id', '$id'), ('$id','$row->user_id')) ORDER BY `chat_id` DESC LIMIT 1");
											$result = $msg->result();
											foreach($result AS $chat){

												if($chat->sender == $row->user_id){

									?>	

										<tr>
											<td>
												<a href="<?php echo base_url()?>dashboard/chat/user/<?php echo $row->user_id;?>">
													<div class="col-md-3">
														<img class="img-circle" src="<?php echo base_url()?>assets/dash/images/avatars/avatar.png"> <br><?php echo $row->name?>
													</div>
													<div class="col-md-8">
														<?php echo  mb_substr($chat->massage, 0, 20)?>.....
													</div>
												</a>
											 </td>
										</tr>

								<?php }else{ ?>

										<tr>

											<td>
												<a href="<?php echo base_url()?>dashboard/chat/user/<?php echo $row->user_id;?>">
													<div class="col-md-3">
														<img class="img-circle" src="<?php echo base_url()?>assets/dash/images/avatars/avatar.png"> <br><?php echo $row->name?>
													</div>
													<div class="col-md-8">
														You: <?php echo  mb_substr($chat->massage, 0, 20)?>.....
													</div>
												</a>
											 </td>

										</tr>
										

								 <?php 	} } }?>

									</tbody>
								</table>
								
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->

							<div class="col-md-5">
								<div class="panel panel-default">
									<div class="panel-heading">
										<div class="panel-title">All Useres</div>
										<div class="panel-body">
											<table class="table table-bordered table-responsive table-hover">
													

													<?php
														$level = $this->session->userdata('level');
														$prse = $this->session->userdata('prse');
														$cat = $this->session->userdata('cat');
														$sub = $this->session->userdata('sub');
														if($level == 2 && $prse == 1){
															$query =$this->db->query("SELECT * FROM `admin` WHERE `level` = 1 ");
															$result = $query->result();
															foreach($result AS $row):
													?>
													<tr>
														<td><b>
															<a href="<?php echo base_url()?>dashboard/chat/user/<?php echo $row->user_id?>">
																<div class="col-md-3">
																	<img class="img-responsive img-circle" src="<?php echo base_url()?>assets/dash/images/avatars/avatar.png">
																</div>
																<div class="col-md-8">
																	<?php echo $row->name?><br>
																	<?php 
																		if($row->level == 1){
																			echo "(Super Admin)";
																		}else{
																			echo "(Admin)";
																		}
																	?>

																</div>
															</a>
															</b>													
														</td>
													</tr>
													
													<?php endforeach; }?>








													<?php

														$level = $this->session->userdata('level');
														$prse = $this->session->userdata('prse');
														$cat = $this->session->userdata('cat');
														$sub = $this->session->userdata('sub');
														if($level==1){
															$sql = "SELECT * FROM `admin` WHERE `prse` = '1'";
														}elseif($level==2 && $prse == 1){
															$sql = "SELECT * FROM `admin` WHERE `cat_id` = '$cat' AND `prse` = 0  ";
														}else{
															$sql = "SELECT * FROM `admin` WHERE `cat_id` = '$cat' ";
														}


														$query = $this->db->query($sql);
														$result = $query->result();
														foreach($result AS $row):
													?>

													<tr>
														<td>
															<a href="<?php echo base_url()?>dashboard/chat/user/<?php echo $row->user_id?>">
																<div class="col-md-3">
																	<img class="img-responsive img-circle" src="<?php echo base_url()?>assets/dash/images/avatars/avatar.png">
																</div>
																<div class="col-md-8">
																	<?php echo $row->name?> (<?php if($row->prse==1){ echo "presedant";}else{echo "Admin";}?>)<br>
																	<?php 
																		if($row->level == 1){
																			echo "(Super Admin)";
																		}
																	?>

																</div>
															</a>													
														</td>
													</tr>
												<?php endforeach; ?>
													
											</table>
										</div>
									</div>
								</div>
							</div>
						</div><!-- /.row -->
					
					
					
					</div><!-- /.page-content -->
				</div>