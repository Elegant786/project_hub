<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'AdminController';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

#Admin Login And Registration

$route['admin-login'] = "AdminController/Index";
$route['registration'] = "AdminController/Registration";
$route['login'] = "AdminController/Login";
$route['logout'] = "AdminController/Logout";
$route['reg-success']="AdminController/RegSuccess";

$route['user-add'] = "AdminController/UserAdd";
$route['edit-add'] = "AdminController/EditUser";
$route['register-user'] = "AdminController/RegisterNewUser";
$route['dashboard/all-users'] = "AdminController/AllUsers";
$route['add-user'] = "AdminController/RegisterNewUser";

//Dashboard

$route['dashboard'] = "Dashboard/Index";

//Category
$route['dashboard/new-category'] = "Dashboard/Category";
$route['dashboard/category/edit/(:any)'] = "Dashboard/EditCategory/$1";
$route['dashboard/category/delete/(:any)'] = "Dashboard/DeleteCategory/$1";
$route['dashboard/view-forms/category/(:any)'] = "Dashboard/ViewFormCateogry/$1";
$route['dashboard/view-forms/category/(:any)/:num'] = "Dashboard/ViewFormCateogry/$1/$1";
$route['dashboard/sub-category/add-new/:num'] = "Dashboard/AddSubCategory";
$route['dashboard/sub-category/edit-new/:num'] = "Dashboard/EditSubCategory";
$route['dashboard/sub-category/edit-new/:num/:num'] = "Dashboard/EditSubCategory/$1/$1";
$route['dashboard/sub/delete'] = "Dashboard/SubDelete";

$route['dashboard/user/add-presedant/(:any)'] = "Dashboard/AddPrecedant/$1";
$route['dashboard/sub-category/add-admin/(:any)/(:any)'] = "Dashboard/SubAdmins";

//Metarials Submission 

$route['dashboard/metarial-submission'] = "Dashboard/MetarialSubmission";
$route['dashboard/metarial-submission/(:any)'] = "Dashboard/MetarialSubmission/$1";
$route['upload-metarials'] = "Dashboard/UploadMetarials";
$route['dashboard/submitted-files'] = "Dashboard/SubmittedFiles";
$route['dashboard/submitted-files/(:any)'] = "Dashboard/SubmittedFiles/$1";
$route['dashboard/view-submitted/(:any)'] = "Dashboard/ViewSubmitted/$1";
$route['dashboard/ajaxform/(:any)'] = "Dashboard/AjaxFormGet/$1";

$route['dashboard/edit-submission'] = "Dashboard/UpdateSubmittedForm";

$route['dashboard/remove-file/(:any)/(:any)'] = "Dashboard/RemoveFile/$1/$1";
$route['dashboard/downloadFile/(:ay)'] ="Dashboard/DownloadFile";

$route['dashboard/view-materials/(:any)'] = "Dashboard/ViewMetarials/$1";

$route['dashboard/approve/(:any)'] = "Dashboard/ApprovedFrom/$1";
$route['dashboard/form-disallowed/(:any)'] = "Dashboard/DisallowedForm/$1";
$route['dashboard/approve-with-suggastions/(:any)'] = "Dashboard/ApprovedSuggastions/$1";

$route['dashboard/user-submited-metarials/(:any)'] = "Dashboard/UserSubmitedMeta/$1";
$route['dashboard/user-submited-metarials'] = "Dashboard/UserSubmitedMeta";
$route['dashboard/user-disallowed-metarials'] = "Dashboard/DisallowedSubmission";
$route['dashboard/user-disallowed-metarials/(:any)'] = "Dashboard/DisallowedSubmission/$1";
$route['dashboard/all-metarials'] = "Dashboard/AllMetas";

$route['dashboard/admin-all-metarials'] = "Dashboard/AdminAllMetas";
$route['dashboard/admin-all-metarials/(:any)'] = "Dashboard/AdminAllMetas/$1";

$route['dashboard/admin-suggastions-forms/(:any)'] = "Dashboard/AdminSuggastionsForms/$1";
$route['dashboard/admin-suggastions-forms'] = "Dashboard/AdminSuggastionsForms";

$route['dashboard/presedant-review-forms/(:any)'] ="Dashboard/PresedantReviedForms/$1";
$route['dashboard/presedant-review-forms'] = "Dashboard/PresedantReviedForms/";

$route['dashboard/approve-super/(:any)'] = "Dashboard/SuperAdminApprove/$1";
$route['dashboard/super-form-disallowed/(:any)'] = "Dashboard/SuperDisallowed/$1";

$route['dashboard/user-all-aproved'] = "Dashboard/FullyApprovedUser";
$route['dashboard/user-all-aproved/(:any)'] = "Dashboard/FullyApprovedUser/$1";

$route['dashboard/user-dis-aproved'] = "Dashboard/UserDisallowed";
$route['dashboard/user-dis-aproved/(:any)'] = "Dashboard/UserDisallowed/$1";

$route['dashboard/my-drafted'] = "Dashboard/MyDrafted";
$route['dashboard/my-drafted/(:any)'] = "Dashboard/MyDrafted/$1";
//UserManagement
$route['dashboard/new-user'] = "AdminController/NewUser";

#Profiling

$route['dashboard/profile'] = "Dashboard/Profile";

$route['dashboard/profile-settings'] = "Dashboard/ProfileSetting";
$route['dashboard/upload-signature'] = "Dashboard/uploadSignature";
$route['dashboard/edit-profile/(:any)'] = "Dashboard/EditProfile";
$route['dashboard/edit-profile'] = "Dashboard/EditProfile";


#Chatting
$route['dashboard/chat/user/:num'] = "Dashboard/UserChatting/$1";
$route['send-maggage'] = "Dashboard/AjaxMsgSend";
$route['dashboard/all-chats'] = "Dashboard/AllMassages";





#Notifications
$route['dashboard/notifications'] = "Dashboard/Notifications";
$route['dashboard/notification/view/(:any)'] = "Dashboard/ShowNotic/$1";
$route['dashboard/user/notification/view/(:any)'] = "Dashboard/ShowUserNotic/$1";
$route['dashboard/user-notifications'] = "Dashboard/UserNotificcation";
$route['dashboard/all-notifications'] = "Dashboard/AllNotification";
$route['dashboard/all-notifications/(:any)'] = "Dashboard/AllNotification/$1";

$route['dashboard/view-admin-notifications/(:any)'] = "Dashboard/AdminsNotifications/$1";
$route['dashboard/view-admin-notifications'] = "Dashboard/AdminsNotifications";



//Settings

$route['dashboard/e-mail-settings'] = "Dashboard/AppEmailSettings";
$route['dashboard/form-review-date/(:any)'] = "Dashboard/FormReviewDate/$1";