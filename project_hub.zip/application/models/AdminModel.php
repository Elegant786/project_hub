<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminModel extends CI_Model {
	public function __construct(){
		parent::__construct();
		//Do your magic here
	}

	//User Registration
	public function Registration(){
		//Generate Password
			$query = $this->db->get('admin');
			$pn = $query->num_rows()+1;
			$pass = date('Y').$pn;
			$password = md5($pass);
		//Generate username
			$uid = date("ym").$pn;

		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$gender = $this->input->post('gender');
		$org = $this->input->post('org');
		$pre = isset($_POST['pre']) ? $_POST['pre']:0;

		$level = isset($_POST['level']) ? $_POST['level']:3;
		@$cat_id = $this->input->post('cat_id');
		if($cat_id==NULL){
			$cat_id = 0;
		}
		$attr = array(

			'uid' 			=> $uid,
			'name'			=> $name,
			'password'		=> $password,
			'email'			=> $email,
			'gender'		=> $gender,
			'organization'	=> $org,
			'level'			=> $level,
			'cat_id'		=> $cat_id,
			'prse'		    => $pre

		);

		$attr2 = array(

			'user_id' => $uid

		);

		if($this->db->insert('admin',$attr)==TRUE && $this->db->insert('signatures',$attr2)){

				$this->load->library('email');
				$this->email->from(email(), 'Abdur Rahaman');
				$this->email->to($email);
				$this->email->cc(Cc());
				$this->email->bcc(Bcc());				
				$this->email->subject('Registration Compleate Successfully');

				$message = "Thank You for Registration. Your User Id = ".$uid." Email is ".$email." Password= ".$pass;

				$this->email->message($message);
				
				if($this->email->send()){
			           return TRUE;
			        }
			        else {
			             return FALSE;
			             //show_error($this->email->print_debugger());
			        }

			}else{
				return FALSE;
			}
	}


	//Login

	public function Login(){
		$username = $this->input->post('username');
		$pass = $this->input->post('password');
		$password = md5($pass);

		$query = $this->db->select("*")
					      ->from('admin')
					      ->where('email',$username)
					      ->where('password',$password)
					      ->get();
		if($query->num_rows()==1){
			$session = array(
				'email' => $query->row(0)->email,
				'name' => $query->row(0)->name,
				'level' => $query->row(0)->level,
				'user_id' => $query->row(0)->user_id,
				'uid' => $query->row(0)->uid,
				'prse' => $query->row(0)->prse,
				'cat' => $query->row(0)->cat_id,
				'sub' => $query->row(0)->sub_id,
				'password' => $query->row(0)->password,
				'image' => $query->row(0)->image,
			);
			$this->session->set_userdata($session);
			return TRUE;
		}else{
			return FALSE;
		}
	
	}
	

#Login Check

	public function CheckLogin(){

		if(empty($this->session->userdata('user_id') ) || $this->session->userdata('user_id')<0 ){
			return FALSE;
		}else{
			return TRUE;
		}
	}

	public function AjaxUserData($email=NULL){
			$query = $this->db->select("*")
							  ->from('admin')
							  ->where('email',$email)
							  ->get();
			return $query->result();
	}

	public function UpdateUser(){

		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$gender = $this->input->post('gender');
		$org = $this->input->post('org');
		$pre = isset($_POST['pre']) ? $_POST['pre']:0;

		$level = isset($_POST['level']) ? $_POST['level']:3;
		$cat_id = $this->input->post('cat_id');
			$attr = array(			
			'name'			=> $name,			
			'email'			=> $email,
			'gender'		=> $gender,
			'organization'	=> $org,
			'level'			=> $level,
			'cat_id'		=> $cat_id,
			'prse'			=> $pre
			);

		$this->db->where('email',$email);
		if($this->db->update('admin',$attr)==TRUE){
			return TRUE;
		}else{
			return FALSE;
		}
	}

	public function NewAdmin(){

		$query = $this->db->get('admin');
		$pn = $query->num_rows()+1;
		$pass = date('Y').$pn;
		$password = md5($pass);	
		$uid = date("ym").$pn;

		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$gender = $this->input->post('gender');		
		$image = $this->upload->data('file_name');

		$attr = array(

			'uid' 			=> $uid,
			'name'			=> $name,
			'password'		=> $password,
			'email'			=> $email,
			'gender'		=> $gender,		
			'level'			=> 2,
			'image'			=> $image,
			

		);
		$attr2 = array(

			'user_id' => $uid

		);

		if($this->db->insert('admin',$attr)==TRUE && $this->db->insert('signatures',$attr2)){

				$this->load->library('email');
				$this->email->from(email(), 'Abdur Rahaman');
				$this->email->to($email);
				$this->email->cc(Cc());
				$this->email->bcc(Bcc());				
				$this->email->subject('Registration Compleate Successfully');

				$message = "Thank You for Registration. Your User Id = ".$uid." Email is ".$email." Password= ".$pass;

				$this->email->message($message);
				$this->email->send();
				return TRUE;

			}else{
				return FALSE;
			}


	}

	
	
	
#End OF FIle
}

/* End of file AdminModel.php */
/* Location: ./application/models/AdminModel.php */
